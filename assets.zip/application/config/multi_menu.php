<?php defined('BASEPATH') OR exit('No direct script access allowed');

// $config["menu_id"]               = 'id';
// $config["menu_label"]            = 'name';
// $config["menu_parent"]           = 'parent';
// $config["menu_icon"] 			 = 'icon';
$config["menu_key"]              = 'slug';
$config["menu_order"]            = 'number';

$config["nav_tag_open"]          = '<ul id="loadedMenu" class="menu-modal">';
$config["nav_tag_close"]         = '</ul>';
$config["item_tag_open"]         = '<li class="list-unstyled">'; 
$config["item_tag_close"]        = '</li>';	
$config["parent_tag_open"]       = '<li>';	
$config["parent_tag_close"]      = '</li>';	
$config["parent_anchor_tag"]     = '<a href="%s">%s</a>';	
$config["children_tag_open"]     = '<div class="megamenu megamenu-quarter-width">
                            <div class="megamenu-row">
                                    <div class="col12"><ul>';	
$config["children_tag_close"]    = '</ul></div>
                                </div>
                            </div>';	
$config['icon_position']		 = 'left'; // 'left' or 'right'
$config['menu_icons_list']		 = array();
// these for the future version
$config['icon_img_base_url']	 = ''; 