<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Affilation extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller i
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function index($subscription_code)
	{
    $this->load->model(array('Subscriptions_model', 'Banners_model'));
    $this->load->database();
    $subscription = $this->Subscriptions_model->get_subscription_by_subscription_code($subscription_code);
    if(!$subscription){
      show_404();
      return;
    }
    $live_banner = $this->Banners_model->get_live_banner_by_channel($subscription->channel_id);
    $this->output->set_status_header(302)->set_header("Location: ".$live_banner->target_url);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */