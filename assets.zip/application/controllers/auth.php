<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

class Auth extends CI_Controller {

  function __construct() {
    log_message('debug', 'initiating auth');
    parent::__construct();
    $this->load->helper(array('form', 'url', 'captcha'));
    $this->load->library(array('form_validation', 'session'));
    $this->load->model(array('Audit_model'));
    $this->load->database();

    $ldap_config = array(
      'ldap_host' => $this->config->item('ldap_host'),
      'ldap_port' => $this->config->item('ldap_port'),
      'ldap_bind_dn' => $this->config->item('ldap_bind_dn'),
      'ldap_bind_pass' => $this->config->item('ldap_bind_pass'),
      'ldap_base_dn' => $this->config->item('ldap_base_dn')
    );
    $this->load->library('ldapauth', $ldap_config);
  }

  public function logout() {
    $ip = $this->input->ip_address();
    $this->load->library('checkauth');
    $user = $this->checkauth->loggedin_user();
    if ($user) {
      $this->Audit_model->log($ip, $user->email, 'logout');
      $this->session->sess_destroy();
    }
    redirect('/');
  }

  public function index() {
    $ip = $this->input->ip_address();
    $this->load->library('checkauth');
    if ($this->checkauth->is_authenticated()) {
      $this->load->helper(array('url'));
      redirect('/home');
    }
//    check if session has captcha
    $has_captch = $this->session->userdata('captcha');

    $this->form_validation->set_rules('username', 'Username', 'required|valid_email');
    $this->form_validation->set_rules('password', 'Password', 'required');
    if ($has_captch) {
      $this->form_validation->set_rules('captcha', 'Captcha', 'required');
    }


    if ($this->form_validation->run() == FALSE) {
      // send it to login page
      $this->_render_login();
    } else {
      // feild validation passed, check for credentials in DB
      $this->load->model(array('Users_model', 'Subscriptions_model', 'Audit_model'));
      $email = $this->input->post('username');
      $password = $this->input->post('password');

      if ($has_captch) {
        $captcha = $this->input->post('captcha');
        if (strcmp($this->session->userdata('captcha'), $captcha) != 0) {
          $this->session->set_flashdata('msg', 'Invalid Captcha !!!');
          redirect('login');
          return;
        }
      }


      $blocked_email = $this->Users_model->is_blocked_email($email);
      if ($blocked_email) {
        $blocked_time = new DateTime($blocked_email->blocked_on);
        $current_time = new DateTime();
        $blocked_durration = $blocked_time->diff($current_time);
//        10 mins lockout
        if ($blocked_durration->i > 10) {
          $this->Users_model->unblock_email($email);
        } else {
          $this->session->set_flashdata('msg', 'Your account is blocked, please contact Administrator !!!');
          redirect('login');
          return;
        }
      }

//       $auth_response = $this->ldapauth->auth($email, $password);
       //if ($auth_response['auth']) {
      if (true) {
        /* authentication successful */
        $luser = $this->Users_model->get_user_by_mail($email);
        if (empty($luser)) {
          $this->session->set_userdata('first_time_subscriber', true);
          /* creating subscriber */
          $this->Users_model->create(array('email' => $email, 'role' => 'subscriber', 'contact_no' => $auth_response['user']['mobile']));
          /* getting it again */
          $luser = $this->Users_model->get_user_by_mail($email);
        }
        $this->session->unset_userdata('login_attempts');
        $this->session->unset_userdata('captcha');
        $this->session->set_userdata('user', $luser);
        $this->Audit_model->log($ip, $email, 'login_success');
        redirect('/home');
      } else {
        log_message('error', serialize($auth_response));
        $login_attempts = $this->session->userdata('login_attempts');
        $login_attempts = $login_attempts ? $login_attempts : 0;
        $this->session->set_userdata('login_attempts', ++$login_attempts);
        if ($login_attempts == 5) {
          $this->Audit_model->log($ip, $email, 'user_blocked');
          $this->Users_model->block_email($email);
          $this->session->set_flashdata('msg', 'Your account is blocked, please contact Administrator !!!');
        } else {
          $this->session->set_flashdata('msg', 'Invalid Username password Combination, Please Try Again !!!');
        }       
        redirect('login');
      }
    }
  }

  private function _render_login() {
    $login_attempts = $this->session->userdata('login_attempts');
    $login_attempts = $login_attempts ? $login_attempts : 0;   
    
    $data = array();
    if ($login_attempts > 2) {
      $vals = $this->config->item('captcha_config');
      $vals['word'] = random_string('alnum', 6);

//    $cap = create_captcha($vals);
      $data['captcha'] = $cap = create_captcha($vals);

      $this->session->set_userdata('captcha', $cap['word']);
    }

    $this->load->model(array('Nodal_model'));
//    $data['nodal_officers'] = $this->Nodal_model->get_officers();
    $this->load->view('commons/header');
    $this->load->view('commons/navigations');
    $this->load->view('login', $data);
    $this->load->view('commons/footer');
  }

}
