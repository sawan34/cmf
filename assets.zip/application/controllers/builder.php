<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Builder extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model(array('Templates_model', 'Sites_model'));
        $this->load->library('checkauth');
    }

    public function index() {

        if (!$this->checkauth->is_authenticated()) {
            $this->load->helper(array('url'));
            redirect('/login');
        }

        $this->load->library('checkauth');
        $user = $this->checkauth->loggedin_user();
        //$this->load->view('templates/build_header');
        $this->load->view('templates/1/1');
        $this->load->view('templates/build_footer');
    }

    public function create() {
        if (empty($_POST)) {
            $this->load->view('commons/header');
            $this->load->view('commons/navigations');
            
            $this->load->view('commons/navigations_auth');
            $this->load->view('website/create');
            $this->load->view('commons/footer');
        } else {            
            $this->form_validation->set_rules('site_url', 'Site URL', 'required');
            if ($this->form_validation->run() == FALSE) {
                
            } else {                
                $site_url = $this->input->post('site_url');                
                $site = array("user_id" => $this->checkauth->loggedin_user()->id,
                    "site_url" => $site_url,
                    "created" => date("Y-m-d H:i:s"),
                    "updated" => date("Y-m-d H:i:s")
                );
                $site_id = $this->Sites_model->create($site);
                redirect("/builder/template/" . $site_id);
            }
        }
    }

    
    public function template($site_id) {
        $data['site_id'] = $site_id;
        $data['templates'] = $templates = $this->Templates_model->get_all_templates();
        $this->load->view('commons/header');
        $this->load->view('commons/navigations');
        $this->load->view('commons/navigations_auth');
        $this->load->view('website/template', $data);
        $this->load->view('commons/footer');
    }

}
