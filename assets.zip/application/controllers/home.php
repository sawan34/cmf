<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller i
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
  
  function __construct() {
    parent::__construct();
   
  }

	public function index()
	{
    $this->load->library('checkauth');
    if(!$this->checkauth->is_authenticated()){
      $this->load->helper(array('url'));
      redirect('/login');
    }
    
    $this->load->library('checkauth');
    $user = $this->checkauth->loggedin_user();
    $this->load->model(array('Subscriptions_model', 'Channels_model','Sites_model'));
    $this->load->database();    
    
    $data['sites'] = $sites = $this->Sites_model->get_user_sites($user->id);
    $this->load->view('commons/header');
    $this->load->view('commons/navigations');
    $this->load->view('commons/navigations_auth');
    if(count($sites)){
      $this->load->view('home/home', $data);
    }else{
      $this->load->view('home/home_no_sites', $data);
    }
    $this->load->view('commons/footer');
	}
  
  public function contact_us(){
    $this->load->library('checkauth');
    
    $this->load->view('commons/header');
    $this->load->view('commons/navigations');
    if($this->checkauth->is_authenticated()){
      $this->load->view('commons/navigations_auth');
    }
    $this->load->view('contact_us');
    $this->load->view('commons/footer');
  }
  
  
  
  
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */