<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SignUp extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        $this->load->library(array('form_validation', 'session'));
        $this->load->model(array('Audit_model'));
        $this->load->database();
	} 

	public function index()
	{
		$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');

		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('password1', 'Password', 'required');
		$this->form_validation->set_rules('password2', 'Password Confirmation', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
        if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('signUpView');
		}
		$this->renderSignUp();
	}

	private function renderSignUp(){
       $this->load->view('commons/header');
       $this->load->view('commons/navigations');
       $this->load->view('signUpView');
       $this->load->view('commons/footer');


	}

}

/* End of file signUp.php */
/* Location: ./application/controllers/signUp.php */				