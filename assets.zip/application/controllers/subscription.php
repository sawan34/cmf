<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

class Subscription extends CI_Controller {

  /**
   * Index Page for this controller.
   *
   * Maps to the following URL
   * 		http://example.com/index.php/welcome
   * 	- or -  
   * 		http://example.com/index.php/welcome/index
   * 	- or -
   * Since this controller is set as the default controller in 
   * config/routes.php, it's displayed at http://example.com/
   *
   * So any other public methods not prefixed with an underscore will
   * map to /index.php/welcome/<method_name>
   * @see http://codeigniter.com/user_guide/general/urls.html
   */
  function __construct() {
    parent::__construct();
    $this->load->library(array('checkauth', 'form_validation'));
    $this->load->helper(array('form', 'url'));
    if (!$this->checkauth->is_authenticated()) {
      $this->load->helper(array('url'));
      redirect('/login');
      return;
    }
  }

  public function index($channel_id = -1) {
    $this->load->model(array('Channels_model'));
    $ch = $this->Channels_model->get_channel($channel_id);
    if($channel_id == -1 || !$ch){
      show_404();
      return;
    }
    if ($this->input->server('REQUEST_METHOD') == 'GET') {
      /* check if user already owns the channel */
      $is_subscribed = $this->checkauth->is_subscribed_to_channel($channel_id);      
      $this->load->database();      
      if ($is_subscribed) {
        $this->_show_subscription($channel_id);
        /* redirects to subscription details page */
      } else {
        /* redirect to banner dimension select page */
        $this->load->library('subscription_wizard');
        $selected_channel = @$this->subscription_wizard->slected_channel();
        $current_step = $this->subscription_wizard->current_step();
        if($selected_channel != $channel_id){
          $current_step = 0;
        }
        if($current_step == 0){
          $this->load->library('subscription_wizard');
          $this->subscription_wizard->start($channel_id);
          $this->_show_step_1();
        }else{
          switch ($current_step) {
            case 1:
              $this->_show_step_1();
              break;
            case 2:
              $this->_show_step_2();
              break;            
            default :
              $this->show_404();
          }
        }
        
      }
    } else {
      $this->load->library('subscription_wizard');
      $current_step = $this->subscription_wizard->current_step();
      switch ($current_step) {
        case 1:
          $this->_wizard_step_1();
          break;
        case 2:
          $this->_wizard_step_2();
          break;
        default :
          $this->show_404();
      }
    }
  }

  private function _show_subscription($channel_id) {    

    $this->load->model(array('Channels_model', 'Banners_model', 'Subscriptions_model'));
    $this->load->database();
    $this->load->library('subscription_wizard', 'checkauth');

    $data['user'] = $user = $this->checkauth->loggedin_user();

    $data['subscription'] = $subscription = $this->Subscriptions_model->get_subscription_by_user($channel_id, $user->id);
    $data['live_banner'] = $live_banner = $this->Banners_model->get_live_banner_by_channel($subscription->channel_id);
    $data['channel'] = $channel = $this->Channels_model->get_channel($subscription->channel_id);
    $data['banner_sizes'] = $this->Banners_model->get_active_banner_sizes();
    $data['channel_image_urls'] = $channel_image_urls = $this->Channels_model->get_channel_image_urls($subscription->channel_id);

    $this->load->view('commons/header');
    $this->load->view('commons/navigations');
    $this->load->view('commons/navigations_auth');
    $this->load->view('subscriptions/subscription_details', $data);
    $this->load->view('commons/footer');
  }

  private function _wizard_step_1() {
    $this->load->model('Banners_model');
    $banner_size = $this->input->post('banner-size');
    
    if(!$this->Banners_model->is_active_banner_size($banner_size)){
      $this->subscription_wizard->finish();
      show_404();
      return;
    }
    
    $this->load->library('subscription_wizard');
    $this->subscription_wizard->set_banner_size($banner_size);
    $this->subscription_wizard->move_next();
    redirect($_SERVER['HTTP_REFERER']);
  }

  private function _show_step_1() {
    $this->load->model(array('Channels_model', 'Banners_model'));
    $this->load->library('subscription_wizard');
    $channel_id = $this->subscription_wizard->slected_channel();


    $data['channel_image_urls'] = $channel_image_urls = $this->Channels_model->get_channel_image_urls($channel_id);
    $data['live_banner'] = $this->Banners_model->get_live_banner_by_channel($channel_id);
    $data['banner_sizes'] = $this->Banners_model->get_active_banner_sizes();
    $data['channel'] = $this->Channels_model->get_channel($channel_id);


    $this->load->view('commons/header');
    $this->load->view('commons/navigations');
    $this->load->view('commons/navigations_auth');
    $this->load->view('subscriptions/wizard_step_1', $data);
    $this->load->view('commons/footer');
  }

  private function _wizard_step_2() {
    $this->form_validation->set_rules('linked-url', 'Linked URL', 'required|callback_valid_url_format');
    $this->form_validation->set_rules('org', 'Organization', 'callback_organization_check');
    if ($this->form_validation->run() == FALSE) {
      $this->_show_step_2();
    } else {
      $this->load->library('subscription_wizard');
      $channel_id = $this->subscription_wizard->slected_channel();
      $banner_size = $this->subscription_wizard->slected_banner_size();

      $this->load->model(array('Subscriptions_model', 'Audit_model'));
      $this->load->database();
      $this->load->library('checkauth');
      $this->load->helper('date');
      $subscription = array(
        'channel_id' => $channel_id,
        'user_id' => $this->checkauth->loggedin_user()->id,
        'linked_url' => $this->input->post('linked-url'),
        'org_id' => $this->input->post('org'),
        'image_dimension_id' => $banner_size,
        'subscription_code' => random_string('alnum', 16),
        'created_at' => now()
      );
      $this->Subscriptions_model->subscribe_user($subscription);

      $ip = $this->input->ip_address();
      $this->Audit_model->log($ip, $this->checkauth->loggedin_user()->email, 'subscriber to channel id' . $channel_id);
      $this->subscription_wizard->finish();
      redirect($_SERVER['HTTP_REFERER']);      
    }
  }

  private function _show_step_2() {

    $this->load->model(array('Channels_model', 'Banners_model'));
    $this->load->database();
    $this->load->library('subscription_wizard');
    $channel_id = $this->subscription_wizard->slected_channel();
    $banner_size = $this->subscription_wizard->slected_banner_size();


    $data['channel_image_urls'] = $channel_image_urls = $this->Channels_model->get_channel_image_urls($channel_id);
    $data['live_banner'] = $this->Banners_model->get_live_banner_by_channel($channel_id);
    $data['banner_sizes'] = $this->Banners_model->get_active_banner_sizes();
    $data['banner_size'] = $banner_size;
    $data['channel'] = $this->Channels_model->get_channel($channel_id);

    $this->load->view('commons/header');
    $this->load->view('commons/navigations');
    $this->load->view('commons/navigations_auth');
    $this->load->view('subscriptions/wizard_step_2', $data);
    $this->load->view('commons/footer');
  }

  private function _show_step_3($subscription_id) {
    $this->load->model(array('Channels_model', 'Banners_model', 'Subscriptions_model'));
    $this->load->database();
    $this->load->library('subscription_wizard');

    $data['subscription'] = $subscription = $this->Subscriptions_model->get_subscription($subscription_id);
    $data['live_banner'] = $live_banner = $this->Banners_model->get_live_banner_by_channel($subscription->channel_id);
    $data['channel'] = $channel = $this->Channels_model->get_channel($subscription->channel_id);
    $data['channel_image_urls'] = $channel_image_urls = $this->Channels_model->get_channel_image_urls($subscription->channel_id);

    $this->load->view('commons/header');
    $this->load->view('commons/navigations');
    $this->load->view('commons/navigations_auth');
    $this->load->view('subscriptions/wizard_step_3', $data);
    $this->load->view('commons/footer');
  }

  public function organization_check($org) {
    if ($org == -1) {
      $this->form_validation->set_message('organization_check', 'Please Select an organization');
      return FALSE;
    }
    return TRUE;
  }

  public function valid_url_format($str) {
    $pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
    if (!preg_match($pattern, $str)) {
      $this->form_validation->set_message('valid_url_format', 'The URL you entered is not correctly formatted.');
      return FALSE;
    }

    return TRUE;
  }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
