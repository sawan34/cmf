<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

class Vocab extends CI_Controller {
  function __construct() {
    parent::__construct();
    
    $this->load->library('checkauth');
    if(!$this->checkauth->is_authenticated()){
      $this->load->helper(array('url'));
      redirect('/login');
    }
   
  }

  public function get_vocab($id) {
    $this->load->model('Vocab_model');
    $this->load->database();
    if ($id == -1) {
      $id = NULL;
    }
    
    $vocab = $this->Vocab_model->get_vocabs($id);
    $this->output->set_content_type('application/json');
    $this->output->set_status_header(200);
    $this->output->set_output(json_encode($vocab));
  }

}
