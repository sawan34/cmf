<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Widget extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model(array('Templates_model', 'Sites_model', 'Site_widgets_model'));
        $this->load->library('checkauth');
    }

    public function index() {

        if (!$this->checkauth->is_authenticated()) {
            $this->load->helper(array('url'));
            redirect('/login');
        }

        $this->load->library('checkauth');
        $user = $this->checkauth->loggedin_user();
        //$this->load->view('templates/build_header');
        $this->load->view('templates/1/1');
        //$this->load->view('templates/build_footer');
    }

    public function siteinfo() {

        $this->form_validation->set_rules('site_title_en', 'English Site Title', 'required');
        $this->form_validation->set_rules('site_title_hi', 'Hindi Site Title', 'required');
        if ($this->form_validation->run() == FALSE) {
            
        } else {
            $site_title_en = $this->input->post('site_title_en');
            $site_title_hi = $this->input->post('site_title_hi');
            $widget_id = $this->input->post('widget_id');
            $widget_area_id = $this->input->post('widget_area_id');
            $site_id = 1;
            $site_title = array(
                "site_title_en" => $site_title_en,
                "site_title_hi" => $site_title_hi,
            );
            $widget_data = json_encode($site_title);
            $site_widget = array("site_id" => $site_id,
                "widget_id" => $widget_id,
                "widget_area_id" => $widget_area_id,
                "widget_data" => $widget_data
            );
            $this->Site_widgets_model->create($site_widget);
        }
    }

    public function update($site_widget_id) {
        $this->form_validation->set_rules('site_title_en', 'English Site Title', 'required');
        $this->form_validation->set_rules('site_title_hi', 'Hindi Site Title', 'required');
        if ($this->form_validation->run() == FALSE) {
            
        } else {
            $site_title_en = $this->input->post('site_title_en');
            $site_title_hi = $this->input->post('site_title_hi');
            $site_title = array(
                "site_title_en" => $site_title_en,
                "site_title_hi" => $site_title_hi,
            );
            $widget_data = json_encode($site_title);            
            $this->Site_widgets_model->update($site_widget_id,$widget_data);
        }
    }

    public function widget_details($widget_id, $site_id) {
        $widget_details = $this->Site_widgets_model->get_widget_details($widget_id, $site_id);  
        if(empty($widget_details)){
                   $response =array('status'=>'error');
                }  else {    
        $response=array('status'=>'success' ,"site_widget_id"=>$widget_details[0]->id,
            "site_id"=>$widget_details[0]->site_id,
            "widget_id"=>$widget_details[0]->widget_id,
            "widget_area_id"=>$widget_details[0]->widget_area_id,
            "widget_data"=>json_decode($widget_details[0]->widget_data));
          }
        $this->output->set_status_header(200)->set_output(json_encode($response))->set_content_type('application/json');
            
    }

}
