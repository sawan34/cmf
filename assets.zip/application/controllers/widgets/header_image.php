<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Header_image extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model(array('Sites_model', 'Site_widgets_model', 'Initiatives_model'));
        $this->load->library('checkauth');
    }

    public function index() {

        if (!$this->checkauth->is_authenticated()) {
            $this->load->helper(array('url'));
            redirect('/login');
        }
        $this->load->library('checkauth');
        $user = $this->checkauth->loggedin_user();
        $initiatives = $this->Initiatives_model->get_initiatives();
        $this->output->set_status_header(200)->set_output(json_encode($initiatives))->set_content_type('application/json');
    }

    public function create() {
        $this->form_validation->set_rules('header_image_title', 'Image Title', 'required');
        if ($this->form_validation->run() == FALSE) {
            
        } else {
            $initiative_id = $this->input->post('initiative_id');
            $widget_id = $this->input->post('widget_id');
            $widget_area_id = $this->input->post('widget_area_id');
            $site_id = 1;
            $widget_data = json_encode(array("initiative_id" => $initiative_id));
            $site_widget = array("site_id" => $site_id,
                "widget_id" => $widget_id,
                "widget_area_id" => $widget_area_id,
                "widget_data" => $widget_data
            );
            $this->Site_widgets_model->create($site_widget);
        }
    }

    public function delete() {
        $site_widget_id = $this->input->post('site_widget_id');
        $this->Site_widgets_model->delete($site_widget_id);
    }

    public function update($site_widget_id) {
        $this->form_validation->set_rules('initiative_id', 'GoI Initiative', 'required');
        if ($this->form_validation->run() == FALSE) {
            
        } else {
            $initiative_id = $this->input->post('initiative_id');
            $widget_data = json_encode(array("initiative_id" => $initiative_id));
            $this->Site_widgets_model->update($site_widget_id, $widget_data);
        }
    }

    public function widget_details($widget_id, $site_id) {
        $widget_details = $this->Site_widgets_model->get_widget_details($widget_id, $site_id);
        $response = "";
        if (!empty($widget_details)) {
            $imageDetails = json_decode($widget_details[0]->widget_data);
            if (count($imageDetails) > 0) {
                $response = array("site_widget_id" => $widget_details[0]->id,
                    "site_id" => $widget_details[0]->site_id,
                    "widget_id" => $widget_details[0]->widget_id,
                    "widget_area_id" => $widget_details[0]->widget_area_id,
                    "image_name" => $widget_details[0]->name,
                    "image_link" => $widget_details[0]->link,
                    "image_url" => $widget_details[0]->image_url,
                );
            }
        }
        $this->output->set_status_header(200)->set_output(json_encode($response))->set_content_type('application/json');
    }

    public function upload() {
        print_r($_POST);
        print_r($_FILES);
    }

}
