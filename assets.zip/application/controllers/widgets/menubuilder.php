<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class menubuilder extends CI_Controller {

	public function __construct()
	{
	parent::__construct();
    $this->load->library('checkauth');
	  $this->load->model(array('Sites_model', 'Site_widgets_model'));
    $this->load->model("menu_model", "menu");
    

	}

	public function index()
	{
		if (!$this->checkauth->is_authenticated()) {
            $this->load->helper(array('url'));
            redirect('/login');
        }
        $this->load->library('checkauth');
        $user = $this->checkauth->loggedin_user();
        echo 'test';
	}
    
    public function get_all_menu($menuType='header-menu'){
      $items = $this->menu->all($menuType);
      $this->load->library("multi_menu");
      $this->multi_menu->set_items($items);
      if($menuType=='header-menu'){
      $homeLink =  '<li class="active"><a href="#"><i class="fa fa-home"></i></a></li>';
      $this->multi_menu->inject_item($homeLink,'first');
       }
      $menus =  $this->multi_menu->render(true);
      echo $menus;
      if(empty($menus)){
          $response = array('status'=>'error');
      }else{
        $response=array('status'=>'success' ,"data"=>$menus);
        
      }
      //$this->output->set_status_header(200)->set_output(json_encode($response))->set_content_type('application/json');        
    } 
    public function getUserMenuItems($widget_id,$site_id,$menu_type='header-menu'){
      $this->load->library("multi_menu");
      $widget_details = $this->Site_widgets_model->get_menu_details($widget_id,$site_id,$menu_type);
      if(empty($widget_details)){
        return '';
      } 
      $arrayData = (array)$widget_details[0];
      $userMenuData = json_decode($arrayData['widget_data'], true);
      $this->multi_menu->set_items($userMenuData);
      $homeLink =  '<li class="active"><a href="#"><i class="fa fa-home"></i></a></li>';
      $this->multi_menu->inject_item($homeLink,'first');
      $menus =  $this->multi_menu->render();
      $this->output->set_status_header(200)->set_output(json_encode(array('site_widget_id'=>$arrayData['id'],'menu'=>$menus,'menuRawJson'=>$arrayData['widget_data'])))->set_content_type('application/json');
      //  exit;
      //(array) $yourObject
    }
    public function insertUserMenuItems(){
       $siteId = $this->input->post('siteID');
       $widget_id = $this->input->post('widget_id');
       $widget_area_id = $this->input->post('widget_area_id');
       $menuData = json_encode($this->input->post('menuData'));
       $siteWidget = array(
         "site_id" => $siteId,
         "widget_id" => $widget_id,
         "widget_area_id" => $widget_area_id,
         "widget_data" => $menuData
        );
      $this->Site_widgets_model->create($siteWidget);
      exit;
    }
	  
    public function updateUserMenuItems(){
       $site_widget_id = $this->input->post('site_widget_id');
       $menuData = json_encode($this->input->post('menuData'));       
       $this->Site_widgets_model->update($site_widget_id,$menuData);
    }

}

/* End of file menubuilder.php */
/* Location: ./application/controllers/menubuilder.php */