<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

// https://ellislab.com/codeigniter/user-guide/general/creating_libraries.html

class Cache_manager {
  private $CI;
  
  public function __construct() {
    $this->CI =& get_instance();
    $this->CI->load->library(array('session'));   
  }
}
