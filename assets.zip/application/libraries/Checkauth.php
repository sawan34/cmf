<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

// https://ellislab.com/codeigniter/user-guide/general/creating_libraries.html

class Checkauth {
  private $CI;
  
  public function __construct() {
    $this->CI =& get_instance();
    $this->CI->load->library(array('session'));   
  }

  public function is_authenticated() {     
    if ($this->CI->session->userdata('user')) {     
      return true;
    } else {
      return false;
    }
  }
  
  public function loggedin_user(){
    $user = $this->CI->session->userdata('user');
    return $user;
  }
  
  public function is_subscribed_to_channel($channel_id){
    $user = $this->CI->session->userdata('user');
    $this->CI->load->helper('array');
    $this->CI->load->model(array('Subscriptions_model'));
    $this->CI->load->database();
    $subscriptions = $this->CI->Subscriptions_model->get_user_subscriptions($user->id);
    $subscriptions = associate_array_with_prop($subscriptions, 'channel_id');
    
    if(key_exists($channel_id, $subscriptions)){
      return true;
    }
    return false;
  }

}
