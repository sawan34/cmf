<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

// https://ellislab.com/codeigniter/user-guide/general/creating_libraries.html

class Subscription_wizard {

  private $CI;
  private $wizard = array();

  public function __construct() {
    $this->CI = & get_instance();
    $this->CI->load->library(array('session'));
    $this->_load_wizard_data();
  }

  public function start($channel_id) {
    $this->_set_wizard_data(array('channel_id' => $channel_id, 'current_step' => 1));
  }

  public function slected_channel() {
    return $this->wizard['channel_id'];
  }
  
  public function slected_banner_size() {
    return $this->wizard['banner_size'];
  }
  
  public function set_banner_size($size){
    $this->_set_wizard_data(array('banner_size' => $size));
  }

  public function current_step() {
    return $this->wizard['current_step'];
  }

  private function _set_wizard_data($val) {
    $this->wizard = array_merge($this->wizard, $val);
    $this->CI->session->set_userdata('subscription_wizard', $this->wizard);
  }

  private function _load_wizard_data() {
    $data = $this->CI->session->userdata('subscription_wizard');
    if (!$data) {
      $this->wizard = array('current_step'=>0);
    } else {
      $this->wizard = $data;
    }
  }

  private function _cancel_wizard() {
    $this->CI->session->unset_userdata('subscription_wizard');
  }

  public function move_next() {
    $this->_set_wizard_data(array('current_step' => $this->wizard['current_step']+1));
  }

  public function move_back() {
    
  }

  public function finish() {
    $this->_cancel_wizard();
  }

}
