<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-02 21:42:30 --> Config Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Hooks Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Utf8 Class Initialized
DEBUG - 2016-03-02 21:42:30 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 21:42:30 --> URI Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Router Class Initialized
DEBUG - 2016-03-02 21:42:30 --> No URI present. Default controller set.
DEBUG - 2016-03-02 21:42:30 --> Output Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Security Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Input Class Initialized
DEBUG - 2016-03-02 21:42:30 --> CRSF cookie Set
DEBUG - 2016-03-02 21:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-02 21:42:30 --> Language Class Initialized
DEBUG - 2016-03-02 21:42:30 --> initiating auth
DEBUG - 2016-03-02 21:42:30 --> Loader Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Controller Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Helper loaded: form_helper
DEBUG - 2016-03-02 21:42:30 --> Helper loaded: url_helper
DEBUG - 2016-03-02 21:42:30 --> Helper loaded: captcha_helper
DEBUG - 2016-03-02 21:42:30 --> Form Validation Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Session Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Helper loaded: string_helper
DEBUG - 2016-03-02 21:42:30 --> Encrypt Class Initialized
DEBUG - 2016-03-02 21:42:30 --> Database Driver Class Initialized
ERROR - 2016-03-02 21:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
DEBUG - 2016-03-02 21:42:31 --> Config Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Hooks Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Utf8 Class Initialized
DEBUG - 2016-03-02 21:42:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 21:42:31 --> URI Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Router Class Initialized
DEBUG - 2016-03-02 21:42:31 --> No URI present. Default controller set.
DEBUG - 2016-03-02 21:42:31 --> Output Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Security Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Input Class Initialized
DEBUG - 2016-03-02 21:42:31 --> CRSF cookie Set
DEBUG - 2016-03-02 21:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-02 21:42:31 --> Language Class Initialized
DEBUG - 2016-03-02 21:42:31 --> initiating auth
DEBUG - 2016-03-02 21:42:31 --> Loader Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Controller Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Helper loaded: form_helper
DEBUG - 2016-03-02 21:42:31 --> Helper loaded: url_helper
DEBUG - 2016-03-02 21:42:31 --> Helper loaded: captcha_helper
DEBUG - 2016-03-02 21:42:31 --> Form Validation Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Session Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Helper loaded: string_helper
DEBUG - 2016-03-02 21:42:31 --> Encrypt Class Initialized
DEBUG - 2016-03-02 21:42:31 --> Database Driver Class Initialized
ERROR - 2016-03-02 21:42:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
DEBUG - 2016-03-02 21:42:47 --> Config Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Hooks Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Utf8 Class Initialized
DEBUG - 2016-03-02 21:42:47 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 21:42:47 --> URI Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Router Class Initialized
DEBUG - 2016-03-02 21:42:47 --> No URI present. Default controller set.
DEBUG - 2016-03-02 21:42:47 --> Output Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Security Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Input Class Initialized
DEBUG - 2016-03-02 21:42:47 --> CRSF cookie Set
DEBUG - 2016-03-02 21:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-02 21:42:47 --> Language Class Initialized
DEBUG - 2016-03-02 21:42:47 --> initiating auth
DEBUG - 2016-03-02 21:42:47 --> Loader Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Controller Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Helper loaded: form_helper
DEBUG - 2016-03-02 21:42:47 --> Helper loaded: url_helper
DEBUG - 2016-03-02 21:42:47 --> Helper loaded: captcha_helper
DEBUG - 2016-03-02 21:42:47 --> Form Validation Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Session Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Helper loaded: string_helper
DEBUG - 2016-03-02 21:42:47 --> Encrypt Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Database Driver Class Initialized
ERROR - 2016-03-02 21:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
DEBUG - 2016-03-02 21:42:47 --> A session cookie was not found.
DEBUG - 2016-03-02 21:42:47 --> Session routines successfully run
DEBUG - 2016-03-02 21:42:47 --> Model Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Model Class Initialized
DEBUG - 2016-03-02 21:42:47 --> Helper loaded: date_helper
DEBUG - 2016-03-02 21:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-02 21:42:47 --> Model Class Initialized
DEBUG - 2016-03-02 21:42:47 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-02 21:42:47 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-02 21:42:47 --> File loaded: application/views/login.php
DEBUG - 2016-03-02 21:42:47 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-02 21:42:47 --> Final output sent to browser
DEBUG - 2016-03-02 21:42:47 --> Total execution time: 0.1133
DEBUG - 2016-03-02 21:43:25 --> Config Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Hooks Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Utf8 Class Initialized
DEBUG - 2016-03-02 21:43:25 --> UTF-8 Support Enabled
DEBUG - 2016-03-02 21:43:25 --> URI Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Router Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Output Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Security Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Input Class Initialized
DEBUG - 2016-03-02 21:43:25 --> XSS Filtering completed
DEBUG - 2016-03-02 21:43:25 --> XSS Filtering completed
DEBUG - 2016-03-02 21:43:25 --> XSS Filtering completed
DEBUG - 2016-03-02 21:43:25 --> XSS Filtering completed
DEBUG - 2016-03-02 21:43:25 --> XSS Filtering completed
DEBUG - 2016-03-02 21:43:25 --> CRSF cookie Set
DEBUG - 2016-03-02 21:43:25 --> CSRF token verified
DEBUG - 2016-03-02 21:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-02 21:43:25 --> Language Class Initialized
DEBUG - 2016-03-02 21:43:25 --> initiating auth
DEBUG - 2016-03-02 21:43:25 --> Loader Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Controller Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Helper loaded: form_helper
DEBUG - 2016-03-02 21:43:25 --> Helper loaded: url_helper
DEBUG - 2016-03-02 21:43:25 --> Helper loaded: captcha_helper
DEBUG - 2016-03-02 21:43:25 --> Form Validation Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Session Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Helper loaded: string_helper
DEBUG - 2016-03-02 21:43:25 --> Encrypt Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Database Driver Class Initialized
ERROR - 2016-03-02 21:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
DEBUG - 2016-03-02 21:43:25 --> Session routines successfully run
DEBUG - 2016-03-02 21:43:25 --> Model Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Model Class Initialized
DEBUG - 2016-03-02 21:43:25 --> Helper loaded: date_helper
DEBUG - 2016-03-02 21:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-02 21:43:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-02 21:43:25 --> Model Class Initialized
DEBUG - 2016-03-02 21:43:25 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-02 21:43:25 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-02 21:43:25 --> File loaded: application/views/login.php
DEBUG - 2016-03-02 21:43:25 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-02 21:43:25 --> Final output sent to browser
DEBUG - 2016-03-02 21:43:25 --> Total execution time: 0.0639
ERROR - 2016-03-02 21:43:30 --> Severity: Warning  --> mysql_pconnect(): Link to server lost, unable to reconnect /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-02 21:43:30 --> Unable to connect to the database
DEBUG - 2016-03-02 21:43:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-03-02 21:43:31 --> Severity: Warning  --> mysql_pconnect(): Link to server lost, unable to reconnect /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-02 21:43:31 --> Unable to connect to the database
DEBUG - 2016-03-02 21:43:31 --> Language file loaded: language/english/db_lang.php
