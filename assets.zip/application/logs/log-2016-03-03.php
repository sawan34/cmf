<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-03 09:44:58 --> Config Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:44:58 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:44:58 --> URI Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Router Class Initialized
DEBUG - 2016-03-03 09:44:58 --> No URI present. Default controller set.
DEBUG - 2016-03-03 09:44:58 --> Output Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Security Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Input Class Initialized
DEBUG - 2016-03-03 09:44:58 --> CRSF cookie Set
DEBUG - 2016-03-03 09:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:44:58 --> Language Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Loader Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Controller Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:44:58 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:44:58 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:44:58 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Session Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:44:58 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:44:58 --> A session cookie was not found.
DEBUG - 2016-03-03 09:44:58 --> Session routines successfully run
DEBUG - 2016-03-03 09:44:58 --> Model Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Config Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Model Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:44:58 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:44:58 --> URI Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Router Class Initialized
DEBUG - 2016-03-03 09:44:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:44:58 --> No URI present. Default controller set.
DEBUG - 2016-03-03 09:44:58 --> Output Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Security Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Model Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Input Class Initialized
DEBUG - 2016-03-03 09:44:59 --> CRSF cookie Set
DEBUG - 2016-03-03 09:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:44:59 --> Language Class Initialized
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:44:59 --> Loader Class Initialized
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/login.php
DEBUG - 2016-03-03 09:44:59 --> Controller Class Initialized
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:44:59 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:44:59 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:44:59 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:44:59 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Session Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:44:59 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:44:59 --> A session cookie was not found.
DEBUG - 2016-03-03 09:44:59 --> Session routines successfully run
DEBUG - 2016-03-03 09:44:59 --> Model Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Model Class Initialized
DEBUG - 2016-03-03 09:44:59 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:44:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:44:59 --> Model Class Initialized
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/login.php
DEBUG - 2016-03-03 09:44:59 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:44:59 --> Final output sent to browser
DEBUG - 2016-03-03 09:44:59 --> Total execution time: 0.6949
DEBUG - 2016-03-03 09:45:00 --> Config Class Initialized
DEBUG - 2016-03-03 09:45:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:45:00 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:45:00 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:45:00 --> URI Class Initialized
DEBUG - 2016-03-03 09:45:00 --> Router Class Initialized
ERROR - 2016-03-03 09:45:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2016-03-03 09:45:12 --> Config Class Initialized
DEBUG - 2016-03-03 09:45:12 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:45:12 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:45:12 --> URI Class Initialized
DEBUG - 2016-03-03 09:45:12 --> Router Class Initialized
DEBUG - 2016-03-03 09:45:12 --> Output Class Initialized
DEBUG - 2016-03-03 09:45:12 --> Security Class Initialized
DEBUG - 2016-03-03 09:45:12 --> Input Class Initialized
DEBUG - 2016-03-03 09:45:12 --> XSS Filtering completed
DEBUG - 2016-03-03 09:45:12 --> XSS Filtering completed
DEBUG - 2016-03-03 09:45:12 --> XSS Filtering completed
DEBUG - 2016-03-03 09:45:12 --> XSS Filtering completed
DEBUG - 2016-03-03 09:45:12 --> XSS Filtering completed
DEBUG - 2016-03-03 09:45:13 --> CRSF cookie Set
DEBUG - 2016-03-03 09:45:13 --> CSRF token verified
DEBUG - 2016-03-03 09:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:45:13 --> Language Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Loader Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Controller Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:45:13 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:45:13 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:45:13 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Session Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:45:13 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Session routines successfully run
DEBUG - 2016-03-03 09:45:13 --> Model Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Model Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:45:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-03 09:45:13 --> Model Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Model Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Config Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:45:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:45:13 --> URI Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Router Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Output Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Security Class Initialized
DEBUG - 2016-03-03 09:45:13 --> Input Class Initialized
DEBUG - 2016-03-03 09:45:13 --> XSS Filtering completed
DEBUG - 2016-03-03 09:45:14 --> CRSF cookie Set
DEBUG - 2016-03-03 09:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:45:14 --> Language Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Loader Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Controller Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Session Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:45:14 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Session routines successfully run
DEBUG - 2016-03-03 09:45:14 --> Checkauth class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:45:14 --> Model Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Model Class Initialized
DEBUG - 2016-03-03 09:45:14 --> Model Class Initialized
DEBUG - 2016-03-03 09:45:14 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:45:14 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:45:14 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:45:14 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:45:14 --> File loaded: application/views/home/home.php
DEBUG - 2016-03-03 09:45:14 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:45:14 --> Final output sent to browser
DEBUG - 2016-03-03 09:45:14 --> Total execution time: 0.9479
DEBUG - 2016-03-03 09:50:08 --> Config Class Initialized
DEBUG - 2016-03-03 09:50:08 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:50:08 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:50:08 --> URI Class Initialized
DEBUG - 2016-03-03 09:50:08 --> Router Class Initialized
DEBUG - 2016-03-03 09:50:08 --> Output Class Initialized
DEBUG - 2016-03-03 09:50:08 --> Security Class Initialized
DEBUG - 2016-03-03 09:50:08 --> Input Class Initialized
DEBUG - 2016-03-03 09:50:08 --> CRSF cookie Set
DEBUG - 2016-03-03 09:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:50:08 --> Language Class Initialized
DEBUG - 2016-03-03 09:50:08 --> Loader Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Controller Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Session Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:50:09 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Session routines successfully run
DEBUG - 2016-03-03 09:50:09 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:50:09 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:50:09 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:50:09 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:09 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:09 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:09 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:09 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:50:09 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:50:09 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:50:09 --> File loaded: application/views/subscriptions/wizard_step_1.php
DEBUG - 2016-03-03 09:50:09 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:50:09 --> Final output sent to browser
DEBUG - 2016-03-03 09:50:09 --> Total execution time: 0.9828
DEBUG - 2016-03-03 09:50:15 --> Config Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:50:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:50:15 --> URI Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Router Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Output Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Security Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Input Class Initialized
DEBUG - 2016-03-03 09:50:15 --> XSS Filtering completed
DEBUG - 2016-03-03 09:50:15 --> XSS Filtering completed
DEBUG - 2016-03-03 09:50:15 --> XSS Filtering completed
DEBUG - 2016-03-03 09:50:15 --> CRSF cookie Set
DEBUG - 2016-03-03 09:50:15 --> CSRF token verified
DEBUG - 2016-03-03 09:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:50:15 --> Language Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Loader Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Controller Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Session Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:50:15 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Session routines successfully run
DEBUG - 2016-03-03 09:50:15 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:50:15 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:50:15 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:50:15 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:16 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Some variable was correctly set
DEBUG - 2016-03-03 09:50:16 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:16 --> Config Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:50:16 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:50:16 --> URI Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Router Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Output Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Security Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Input Class Initialized
DEBUG - 2016-03-03 09:50:16 --> XSS Filtering completed
DEBUG - 2016-03-03 09:50:16 --> CRSF cookie Set
DEBUG - 2016-03-03 09:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:50:16 --> Language Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Loader Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Controller Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Session Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:50:16 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Session routines successfully run
DEBUG - 2016-03-03 09:50:16 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:50:16 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:50:16 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:16 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:50:17 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:17 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:17 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:50:17 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:50:17 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:50:17 --> File loaded: application/views/subscriptions/wizard_step_2.php
DEBUG - 2016-03-03 09:50:17 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:50:17 --> Final output sent to browser
DEBUG - 2016-03-03 09:50:17 --> Total execution time: 1.0484
DEBUG - 2016-03-03 09:50:17 --> Config Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:50:17 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:50:17 --> URI Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Router Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Output Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Security Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Input Class Initialized
DEBUG - 2016-03-03 09:50:17 --> XSS Filtering completed
DEBUG - 2016-03-03 09:50:17 --> CRSF cookie Set
DEBUG - 2016-03-03 09:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:50:17 --> Language Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Loader Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Controller Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Session Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:50:17 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:50:17 --> Session routines successfully run
DEBUG - 2016-03-03 09:50:18 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:18 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:18 --> Final output sent to browser
DEBUG - 2016-03-03 09:50:18 --> Total execution time: 0.6407
DEBUG - 2016-03-03 09:50:35 --> Config Class Initialized
DEBUG - 2016-03-03 09:50:35 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:50:36 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:50:36 --> URI Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Router Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Output Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Security Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Input Class Initialized
DEBUG - 2016-03-03 09:50:36 --> XSS Filtering completed
DEBUG - 2016-03-03 09:50:36 --> CRSF cookie Set
DEBUG - 2016-03-03 09:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:50:36 --> Language Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Loader Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Controller Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:50:36 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:50:36 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:50:36 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Session Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:50:36 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Session routines successfully run
DEBUG - 2016-03-03 09:50:36 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:36 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:50:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:36 --> Config Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:50:37 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:50:37 --> URI Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Router Class Initialized
DEBUG - 2016-03-03 09:50:37 --> No URI present. Default controller set.
DEBUG - 2016-03-03 09:50:37 --> Output Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Security Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Input Class Initialized
DEBUG - 2016-03-03 09:50:37 --> XSS Filtering completed
DEBUG - 2016-03-03 09:50:37 --> CRSF cookie Set
DEBUG - 2016-03-03 09:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:50:37 --> Language Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Loader Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Controller Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:50:37 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:50:37 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:50:37 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Session Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:50:37 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:50:37 --> A session cookie was not found.
DEBUG - 2016-03-03 09:50:37 --> Session routines successfully run
DEBUG - 2016-03-03 09:50:37 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:37 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:50:37 --> Model Class Initialized
DEBUG - 2016-03-03 09:50:37 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:50:37 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:50:37 --> File loaded: application/views/login.php
DEBUG - 2016-03-03 09:50:37 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:50:37 --> Final output sent to browser
DEBUG - 2016-03-03 09:50:37 --> Total execution time: 0.9198
DEBUG - 2016-03-03 09:51:09 --> Config Class Initialized
DEBUG - 2016-03-03 09:51:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:51:09 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:51:09 --> URI Class Initialized
DEBUG - 2016-03-03 09:51:09 --> Router Class Initialized
DEBUG - 2016-03-03 09:51:09 --> Output Class Initialized
DEBUG - 2016-03-03 09:51:09 --> Security Class Initialized
DEBUG - 2016-03-03 09:51:09 --> Input Class Initialized
DEBUG - 2016-03-03 09:51:09 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:09 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:09 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:09 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:09 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:09 --> CRSF cookie Set
DEBUG - 2016-03-03 09:51:09 --> CSRF token verified
DEBUG - 2016-03-03 09:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:51:10 --> Language Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Loader Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Controller Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:51:10 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:51:10 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:51:10 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Session Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:51:10 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Session routines successfully run
DEBUG - 2016-03-03 09:51:10 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-03 09:51:10 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Config Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:51:10 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:51:10 --> URI Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Router Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Output Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Security Class Initialized
DEBUG - 2016-03-03 09:51:10 --> Input Class Initialized
DEBUG - 2016-03-03 09:51:10 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:11 --> CRSF cookie Set
DEBUG - 2016-03-03 09:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:51:11 --> Language Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Loader Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Controller Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Session Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:51:11 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Session routines successfully run
DEBUG - 2016-03-03 09:51:11 --> Checkauth class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:11 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:11 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:11 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:51:11 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:51:11 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:51:11 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:51:11 --> File loaded: application/views/home/home.php
DEBUG - 2016-03-03 09:51:11 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:51:11 --> Final output sent to browser
DEBUG - 2016-03-03 09:51:11 --> Total execution time: 0.9572
DEBUG - 2016-03-03 09:51:14 --> Config Class Initialized
DEBUG - 2016-03-03 09:51:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:51:14 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:51:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:51:14 --> URI Class Initialized
DEBUG - 2016-03-03 09:51:14 --> Router Class Initialized
DEBUG - 2016-03-03 09:51:14 --> Output Class Initialized
DEBUG - 2016-03-03 09:51:14 --> Security Class Initialized
DEBUG - 2016-03-03 09:51:14 --> Input Class Initialized
DEBUG - 2016-03-03 09:51:14 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:14 --> CRSF cookie Set
DEBUG - 2016-03-03 09:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:51:14 --> Language Class Initialized
DEBUG - 2016-03-03 09:51:14 --> Loader Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Controller Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Session Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:51:15 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Session routines successfully run
DEBUG - 2016-03-03 09:51:15 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:51:15 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:51:15 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:51:15 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:15 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:15 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:15 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:15 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:51:15 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:51:15 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:51:15 --> File loaded: application/views/subscriptions/wizard_step_1.php
DEBUG - 2016-03-03 09:51:15 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:51:15 --> Final output sent to browser
DEBUG - 2016-03-03 09:51:15 --> Total execution time: 1.0455
DEBUG - 2016-03-03 09:51:19 --> Config Class Initialized
DEBUG - 2016-03-03 09:51:19 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:51:19 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:51:19 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:51:19 --> URI Class Initialized
DEBUG - 2016-03-03 09:51:19 --> Router Class Initialized
DEBUG - 2016-03-03 09:51:19 --> Output Class Initialized
DEBUG - 2016-03-03 09:51:19 --> Security Class Initialized
DEBUG - 2016-03-03 09:51:19 --> Input Class Initialized
DEBUG - 2016-03-03 09:51:19 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:19 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:19 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:19 --> CRSF cookie Set
DEBUG - 2016-03-03 09:51:20 --> CSRF token verified
DEBUG - 2016-03-03 09:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:51:20 --> Language Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Loader Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Controller Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Session Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:51:20 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Session routines successfully run
DEBUG - 2016-03-03 09:51:20 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:51:20 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:51:20 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:20 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:20 --> >>>>>>>>>>>>>>>>>>Some variable was correctly set
DEBUG - 2016-03-03 09:51:20 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:20 --> Config Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:51:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:51:20 --> URI Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Router Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Output Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Security Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Input Class Initialized
DEBUG - 2016-03-03 09:51:20 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:20 --> CRSF cookie Set
DEBUG - 2016-03-03 09:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:51:20 --> Language Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Loader Class Initialized
DEBUG - 2016-03-03 09:51:20 --> Controller Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Session Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:51:21 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Session routines successfully run
DEBUG - 2016-03-03 09:51:21 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:51:21 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:51:21 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:51:21 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:21 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:51:21 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:51:21 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:51:21 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:51:21 --> File loaded: application/views/subscriptions/wizard_step_2.php
DEBUG - 2016-03-03 09:51:21 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:51:21 --> Final output sent to browser
DEBUG - 2016-03-03 09:51:21 --> Total execution time: 1.1212
DEBUG - 2016-03-03 09:51:21 --> Config Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:51:21 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:51:21 --> URI Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Router Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Output Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Security Class Initialized
DEBUG - 2016-03-03 09:51:21 --> Input Class Initialized
DEBUG - 2016-03-03 09:51:22 --> XSS Filtering completed
DEBUG - 2016-03-03 09:51:22 --> CRSF cookie Set
DEBUG - 2016-03-03 09:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:51:22 --> Language Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Loader Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Controller Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Session Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:51:22 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Session routines successfully run
DEBUG - 2016-03-03 09:51:22 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Model Class Initialized
DEBUG - 2016-03-03 09:51:22 --> Final output sent to browser
DEBUG - 2016-03-03 09:51:22 --> Total execution time: 0.5855
DEBUG - 2016-03-03 09:53:07 --> Config Class Initialized
DEBUG - 2016-03-03 09:53:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:53:07 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:53:07 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:53:07 --> URI Class Initialized
DEBUG - 2016-03-03 09:53:07 --> Router Class Initialized
DEBUG - 2016-03-03 09:53:07 --> No URI present. Default controller set.
DEBUG - 2016-03-03 09:53:07 --> Output Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Security Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Input Class Initialized
DEBUG - 2016-03-03 09:53:08 --> CRSF cookie Set
DEBUG - 2016-03-03 09:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:53:08 --> Language Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Loader Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Controller Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:53:08 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:53:08 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:53:08 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Session Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:53:08 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:53:08 --> A session cookie was not found.
DEBUG - 2016-03-03 09:53:08 --> Session routines successfully run
DEBUG - 2016-03-03 09:53:08 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:08 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:53:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:53:08 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:08 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:53:08 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:53:08 --> File loaded: application/views/login.php
DEBUG - 2016-03-03 09:53:08 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:53:08 --> Final output sent to browser
DEBUG - 2016-03-03 09:53:08 --> Total execution time: 1.2633
DEBUG - 2016-03-03 09:53:14 --> Config Class Initialized
DEBUG - 2016-03-03 09:53:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:53:14 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:53:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:53:14 --> URI Class Initialized
DEBUG - 2016-03-03 09:53:14 --> Router Class Initialized
ERROR - 2016-03-03 09:53:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2016-03-03 09:53:35 --> Config Class Initialized
DEBUG - 2016-03-03 09:53:35 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:53:36 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:53:36 --> URI Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Router Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Output Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Security Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Input Class Initialized
DEBUG - 2016-03-03 09:53:36 --> XSS Filtering completed
DEBUG - 2016-03-03 09:53:36 --> XSS Filtering completed
DEBUG - 2016-03-03 09:53:36 --> XSS Filtering completed
DEBUG - 2016-03-03 09:53:36 --> XSS Filtering completed
DEBUG - 2016-03-03 09:53:36 --> XSS Filtering completed
DEBUG - 2016-03-03 09:53:36 --> CRSF cookie Set
DEBUG - 2016-03-03 09:53:36 --> CSRF token verified
DEBUG - 2016-03-03 09:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:53:36 --> Language Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Loader Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Controller Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:53:36 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:53:36 --> Helper loaded: captcha_helper
DEBUG - 2016-03-03 09:53:36 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Session Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:53:36 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Session routines successfully run
DEBUG - 2016-03-03 09:53:36 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:53:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-03 09:53:36 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:36 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Config Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:53:37 --> URI Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Router Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Output Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Security Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Input Class Initialized
DEBUG - 2016-03-03 09:53:37 --> XSS Filtering completed
DEBUG - 2016-03-03 09:53:37 --> CRSF cookie Set
DEBUG - 2016-03-03 09:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:53:37 --> Language Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Loader Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Controller Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Session Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:53:37 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Session routines successfully run
DEBUG - 2016-03-03 09:53:37 --> Checkauth class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:53:37 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:37 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:37 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:53:37 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:53:37 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:53:37 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:53:38 --> File loaded: application/views/home/home.php
DEBUG - 2016-03-03 09:53:38 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:53:38 --> Final output sent to browser
DEBUG - 2016-03-03 09:53:38 --> Total execution time: 1.0166
DEBUG - 2016-03-03 09:53:59 --> Config Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:53:59 --> URI Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Router Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Output Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Security Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Input Class Initialized
DEBUG - 2016-03-03 09:53:59 --> XSS Filtering completed
DEBUG - 2016-03-03 09:53:59 --> CRSF cookie Set
DEBUG - 2016-03-03 09:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:53:59 --> Language Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Loader Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Controller Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Session Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:53:59 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Session routines successfully run
DEBUG - 2016-03-03 09:53:59 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:53:59 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:53:59 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:53:59 --> Model Class Initialized
DEBUG - 2016-03-03 09:53:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:53:59 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:54:00 --> Model Class Initialized
DEBUG - 2016-03-03 09:54:00 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:54:00 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:54:00 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:54:00 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:54:00 --> File loaded: application/views/subscriptions/wizard_step_1.php
DEBUG - 2016-03-03 09:54:00 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:54:00 --> Final output sent to browser
DEBUG - 2016-03-03 09:54:00 --> Total execution time: 1.0437
DEBUG - 2016-03-03 09:55:21 --> Config Class Initialized
DEBUG - 2016-03-03 09:55:21 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:55:21 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:55:21 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:55:21 --> URI Class Initialized
DEBUG - 2016-03-03 09:55:21 --> Router Class Initialized
DEBUG - 2016-03-03 09:55:21 --> Output Class Initialized
DEBUG - 2016-03-03 09:55:21 --> Security Class Initialized
DEBUG - 2016-03-03 09:55:21 --> Input Class Initialized
DEBUG - 2016-03-03 09:55:21 --> XSS Filtering completed
DEBUG - 2016-03-03 09:55:21 --> XSS Filtering completed
DEBUG - 2016-03-03 09:55:31 --> Config Class Initialized
DEBUG - 2016-03-03 09:55:31 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:55:31 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:55:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:55:31 --> URI Class Initialized
DEBUG - 2016-03-03 09:55:31 --> Router Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Output Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Security Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Input Class Initialized
DEBUG - 2016-03-03 09:55:32 --> CRSF cookie Set
DEBUG - 2016-03-03 09:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:55:32 --> Language Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Loader Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Controller Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Session Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:55:32 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Session routines successfully run
DEBUG - 2016-03-03 09:55:32 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:55:32 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:55:32 --> Model Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Model Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:55:32 --> Model Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:55:32 --> Model Class Initialized
DEBUG - 2016-03-03 09:55:32 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:55:32 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:55:32 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:55:32 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:55:32 --> File loaded: application/views/subscriptions/wizard_step_1.php
DEBUG - 2016-03-03 09:55:32 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:55:32 --> Final output sent to browser
DEBUG - 2016-03-03 09:55:32 --> Total execution time: 1.1363
DEBUG - 2016-03-03 09:56:05 --> Config Class Initialized
DEBUG - 2016-03-03 09:56:05 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:56:05 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:56:05 --> URI Class Initialized
DEBUG - 2016-03-03 09:56:05 --> Router Class Initialized
DEBUG - 2016-03-03 09:56:05 --> Output Class Initialized
DEBUG - 2016-03-03 09:56:05 --> Security Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Input Class Initialized
DEBUG - 2016-03-03 09:56:06 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:06 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:06 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:06 --> CRSF cookie Set
DEBUG - 2016-03-03 09:56:06 --> CSRF token verified
DEBUG - 2016-03-03 09:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:56:06 --> Language Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Loader Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Controller Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Session Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:56:06 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Session routines successfully run
DEBUG - 2016-03-03 09:56:06 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:56:06 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:56:06 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:56:06 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:06 --> >>>>>>>>>>>>>>>>>>Some variable was correctly set
DEBUG - 2016-03-03 09:56:06 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:56:06 --> Config Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:56:06 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:56:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:56:06 --> URI Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Router Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Output Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Security Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Input Class Initialized
DEBUG - 2016-03-03 09:56:07 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:07 --> CRSF cookie Set
DEBUG - 2016-03-03 09:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:56:07 --> Language Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Loader Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Controller Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Session Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:56:07 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Session routines successfully run
DEBUG - 2016-03-03 09:56:07 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:56:07 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:56:07 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:56:07 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:56:07 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:07 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:56:07 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:56:07 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:56:07 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:56:07 --> File loaded: application/views/subscriptions/wizard_step_2.php
DEBUG - 2016-03-03 09:56:07 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:56:08 --> Final output sent to browser
DEBUG - 2016-03-03 09:56:08 --> Total execution time: 1.1554
DEBUG - 2016-03-03 09:56:08 --> Config Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:56:08 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:56:08 --> URI Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Router Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Output Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Security Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Input Class Initialized
DEBUG - 2016-03-03 09:56:08 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:08 --> CRSF cookie Set
DEBUG - 2016-03-03 09:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:56:08 --> Language Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Loader Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Controller Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Session Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:56:08 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Session routines successfully run
DEBUG - 2016-03-03 09:56:08 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:08 --> Final output sent to browser
DEBUG - 2016-03-03 09:56:08 --> Total execution time: 0.6804
DEBUG - 2016-03-03 09:56:14 --> Config Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:56:14 --> URI Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Router Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Output Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Security Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Input Class Initialized
DEBUG - 2016-03-03 09:56:14 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:14 --> CRSF cookie Set
DEBUG - 2016-03-03 09:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:56:14 --> Language Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Loader Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Controller Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Session Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:56:14 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:56:14 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:56:15 --> Session routines successfully run
DEBUG - 2016-03-03 09:56:15 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:15 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:15 --> Final output sent to browser
DEBUG - 2016-03-03 09:56:15 --> Total execution time: 0.7179
DEBUG - 2016-03-03 09:56:22 --> Config Class Initialized
DEBUG - 2016-03-03 09:56:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:56:22 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:56:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:56:22 --> URI Class Initialized
DEBUG - 2016-03-03 09:56:22 --> Router Class Initialized
DEBUG - 2016-03-03 09:56:22 --> Output Class Initialized
DEBUG - 2016-03-03 09:56:22 --> Security Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Input Class Initialized
DEBUG - 2016-03-03 09:56:23 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:23 --> CRSF cookie Set
DEBUG - 2016-03-03 09:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:56:23 --> Language Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Loader Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Controller Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Session Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:56:23 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Session routines successfully run
DEBUG - 2016-03-03 09:56:23 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:23 --> Final output sent to browser
DEBUG - 2016-03-03 09:56:23 --> Total execution time: 0.6896
DEBUG - 2016-03-03 09:56:26 --> Config Class Initialized
DEBUG - 2016-03-03 09:56:26 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:56:26 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:56:26 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:56:26 --> URI Class Initialized
DEBUG - 2016-03-03 09:56:26 --> Router Class Initialized
DEBUG - 2016-03-03 09:56:26 --> Output Class Initialized
DEBUG - 2016-03-03 09:56:26 --> Security Class Initialized
DEBUG - 2016-03-03 09:56:26 --> Input Class Initialized
DEBUG - 2016-03-03 09:56:26 --> XSS Filtering completed
DEBUG - 2016-03-03 09:56:26 --> CRSF cookie Set
DEBUG - 2016-03-03 09:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:56:27 --> Language Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Loader Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Controller Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Session Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:56:27 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Session routines successfully run
DEBUG - 2016-03-03 09:56:27 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Model Class Initialized
DEBUG - 2016-03-03 09:56:27 --> Final output sent to browser
DEBUG - 2016-03-03 09:56:27 --> Total execution time: 0.7466
DEBUG - 2016-03-03 09:57:02 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:02 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:02 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:02 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:02 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:02 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:02 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:02 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:02 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:02 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:02 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:02 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:03 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:03 --> CSRF token verified
DEBUG - 2016-03-03 09:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:03 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:03 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:03 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:57:03 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:57:03 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-03 09:57:03 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:03 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:57:03 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:57:03 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:57:03 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:57:03 --> File loaded: application/views/subscriptions/wizard_step_2.php
DEBUG - 2016-03-03 09:57:03 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:57:03 --> Final output sent to browser
DEBUG - 2016-03-03 09:57:03 --> Total execution time: 1.3040
DEBUG - 2016-03-03 09:57:03 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:03 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:03 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:04 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:04 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:04 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:04 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:04 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:04 --> Final output sent to browser
DEBUG - 2016-03-03 09:57:04 --> Total execution time: 0.6729
DEBUG - 2016-03-03 09:57:17 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:17 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:17 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:17 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:17 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:17 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:17 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:17 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:17 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:17 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:17 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:17 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:17 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:17 --> CSRF token verified
DEBUG - 2016-03-03 09:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:17 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:18 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:18 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:57:18 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:57:18 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-03 09:57:18 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:18 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:57:18 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:57:18 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:57:18 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:57:18 --> File loaded: application/views/subscriptions/wizard_step_2.php
DEBUG - 2016-03-03 09:57:18 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:57:18 --> Final output sent to browser
DEBUG - 2016-03-03 09:57:18 --> Total execution time: 1.2517
DEBUG - 2016-03-03 09:57:18 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:18 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:18 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:19 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:19 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:19 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:19 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:19 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:19 --> Final output sent to browser
DEBUG - 2016-03-03 09:57:19 --> Total execution time: 0.7240
DEBUG - 2016-03-03 09:57:22 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:22 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:22 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:22 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:22 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:22 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:22 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:22 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:23 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:23 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:23 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:23 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:23 --> Final output sent to browser
DEBUG - 2016-03-03 09:57:23 --> Total execution time: 0.9444
DEBUG - 2016-03-03 09:57:26 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:26 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:26 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:26 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:26 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:26 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:26 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:27 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:27 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:27 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:27 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:27 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:27 --> Final output sent to browser
DEBUG - 2016-03-03 09:57:27 --> Total execution time: 0.8763
DEBUG - 2016-03-03 09:57:27 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:27 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:28 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:28 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:28 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:28 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:28 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:28 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:28 --> CSRF token verified
DEBUG - 2016-03-03 09:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:28 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:28 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:28 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:57:28 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:57:28 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:28 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-03 09:57:29 --> Subscription_wizard class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:29 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:57:29 --> Checkauth class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:29 --> Config Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Utf8 Class Initialized
DEBUG - 2016-03-03 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 09:57:29 --> URI Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Router Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Output Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Security Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Input Class Initialized
DEBUG - 2016-03-03 09:57:29 --> XSS Filtering completed
DEBUG - 2016-03-03 09:57:29 --> CRSF cookie Set
DEBUG - 2016-03-03 09:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 09:57:29 --> Language Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Loader Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Controller Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Session Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Helper loaded: string_helper
DEBUG - 2016-03-03 09:57:29 --> Encrypt Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Database Driver Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Session routines successfully run
DEBUG - 2016-03-03 09:57:29 --> Helper loaded: form_helper
DEBUG - 2016-03-03 09:57:29 --> Form Validation Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Helper loaded: url_helper
DEBUG - 2016-03-03 09:57:29 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:29 --> Helper loaded: array_helper
DEBUG - 2016-03-03 09:57:29 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:30 --> Model Class Initialized
DEBUG - 2016-03-03 09:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-03 09:57:30 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 09:57:30 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 09:57:30 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 09:57:30 --> Helper loaded: date_helper
DEBUG - 2016-03-03 09:57:30 --> File loaded: application/views/subscriptions/subscription_details.php
DEBUG - 2016-03-03 09:57:30 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 09:57:30 --> Final output sent to browser
DEBUG - 2016-03-03 09:57:30 --> Total execution time: 1.1173
DEBUG - 2016-03-03 10:01:43 --> Config Class Initialized
DEBUG - 2016-03-03 10:01:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:01:43 --> Utf8 Class Initialized
DEBUG - 2016-03-03 10:01:43 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 10:01:43 --> URI Class Initialized
DEBUG - 2016-03-03 10:01:43 --> Router Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Output Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Security Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Input Class Initialized
DEBUG - 2016-03-03 10:01:44 --> CRSF cookie Set
DEBUG - 2016-03-03 10:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 10:01:44 --> Language Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Loader Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Controller Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Session Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Helper loaded: string_helper
DEBUG - 2016-03-03 10:01:44 --> Encrypt Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Database Driver Class Initialized
DEBUG - 2016-03-03 10:01:44 --> Session routines successfully run
DEBUG - 2016-03-03 10:01:44 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 10:01:44 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 10:01:44 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 10:01:44 --> File loaded: application/views/contact_us.php
DEBUG - 2016-03-03 10:01:44 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 10:01:44 --> Final output sent to browser
DEBUG - 2016-03-03 10:01:44 --> Total execution time: 0.8216
DEBUG - 2016-03-03 10:01:50 --> Config Class Initialized
DEBUG - 2016-03-03 10:01:50 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:01:50 --> Utf8 Class Initialized
DEBUG - 2016-03-03 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2016-03-03 10:01:51 --> URI Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Router Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Output Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Security Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Input Class Initialized
DEBUG - 2016-03-03 10:01:51 --> XSS Filtering completed
DEBUG - 2016-03-03 10:01:51 --> CRSF cookie Set
DEBUG - 2016-03-03 10:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-03 10:01:51 --> Language Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Loader Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Controller Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Session Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Helper loaded: string_helper
DEBUG - 2016-03-03 10:01:51 --> Encrypt Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Database Driver Class Initialized
DEBUG - 2016-03-03 10:01:51 --> Session routines successfully run
DEBUG - 2016-03-03 10:01:51 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-03 10:01:51 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-03 10:01:51 --> File loaded: application/views/commons/navigations_auth.php
DEBUG - 2016-03-03 10:01:51 --> File loaded: application/views/feedback.php
DEBUG - 2016-03-03 10:01:51 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-03 10:01:51 --> Final output sent to browser
DEBUG - 2016-03-03 10:01:51 --> Total execution time: 0.7993
ERROR - 2016-03-03 10:03:58 --> >>>>>>>>>>>>>>>>>>Some variable was correctly set
ERROR - 2016-03-03 10:10:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-03 10:12:15 --> row is >>>>>>>>> 1
ERROR - 2016-03-03 10:12:16 --> Severity: Notice  --> Undefined index: 6ddd /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 5
ERROR - 2016-03-03 10:12:16 --> Severity: Notice  --> Undefined index: 6ddd /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 6
ERROR - 2016-03-03 10:12:16 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 16
ERROR - 2016-03-03 10:12:17 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:12:17 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:18:47 --> Severity: 4096  --> Object of class CI_DB_mysql_driver could not be converted to string /home1/cbps/docs/application/models/banners_model.php 19
ERROR - 2016-03-03 10:18:47 --> query is  
ERROR - 2016-03-03 10:18:47 --> row id is >>>>>>>>> 1
ERROR - 2016-03-03 10:18:47 --> row is >>>>>>>>> {"id":"6","width":"1800","height":"450","is_active":"1"}
ERROR - 2016-03-03 10:19:23 --> Severity: Notice  --> Undefined index: 6ew /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 5
ERROR - 2016-03-03 10:19:23 --> Severity: Notice  --> Undefined index: 6ew /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 6
ERROR - 2016-03-03 10:19:23 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 16
ERROR - 2016-03-03 10:19:23 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:19:23 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:21:48 --> Size  id is >>>>>>>>> 6jijiji
ERROR - 2016-03-03 10:21:48 --> query is  SELECT *
FROM (`image_dimensions_master`)
WHERE `is_active` =  1
AND `id` =  '6jijiji'
ERROR - 2016-03-03 10:21:48 --> row id is >>>>>>>>> 1
ERROR - 2016-03-03 10:21:48 --> row is >>>>>>>>> {"id":"6","width":"1800","height":"450","is_active":"1"}
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Undefined index: 6jijiji /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 5
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Undefined index: 6jijiji /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 5
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Undefined index: 6jijiji /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 6
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Undefined index: 6jijiji /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 6
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 16
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 16
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:35:27 --> Severity: Notice  --> Trying to get property of non-object /home1/cbps/docs/application/views/subscriptions/wizard_step_2.php 17
ERROR - 2016-03-03 10:36:32 --> 404 Page Not Found --> 
ERROR - 2016-03-03 10:57:53 --> 404 Page Not Found --> manual
ERROR - 2016-03-03 11:08:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-03 11:08:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-03 11:08:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-03 11:13:11 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:13:39 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:14:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-03 11:14:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-03 11:15:37 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:16:38 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:17:03 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:17:05 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:17:11 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:17:13 --> 404 Page Not Found --> 
ERROR - 2016-03-03 11:20:12 --> 404 Page Not Found --> 
