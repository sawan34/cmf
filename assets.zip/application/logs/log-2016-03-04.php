<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-04 12:01:01 --> Config Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Utf8 Class Initialized
DEBUG - 2016-03-04 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2016-03-04 12:01:01 --> URI Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Router Class Initialized
DEBUG - 2016-03-04 12:01:01 --> No URI present. Default controller set.
DEBUG - 2016-03-04 12:01:01 --> Output Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Security Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Input Class Initialized
DEBUG - 2016-03-04 12:01:01 --> CRSF cookie Set
DEBUG - 2016-03-04 12:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-04 12:01:01 --> Language Class Initialized
DEBUG - 2016-03-04 12:01:01 --> initiating auth
DEBUG - 2016-03-04 12:01:01 --> Loader Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Controller Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Helper loaded: form_helper
DEBUG - 2016-03-04 12:01:01 --> Helper loaded: url_helper
DEBUG - 2016-03-04 12:01:01 --> Helper loaded: captcha_helper
DEBUG - 2016-03-04 12:01:01 --> Form Validation Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Session Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Helper loaded: string_helper
DEBUG - 2016-03-04 12:01:01 --> Encrypt Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Database Driver Class Initialized
ERROR - 2016-03-04 12:01:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
DEBUG - 2016-03-04 12:01:01 --> A session cookie was not found.
DEBUG - 2016-03-04 12:01:01 --> Session routines successfully run
DEBUG - 2016-03-04 12:01:01 --> Model Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Model Class Initialized
DEBUG - 2016-03-04 12:01:01 --> Helper loaded: date_helper
DEBUG - 2016-03-04 12:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-04 12:01:01 --> Model Class Initialized
DEBUG - 2016-03-04 12:01:01 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-04 12:01:01 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-04 12:01:01 --> File loaded: application/views/login.php
DEBUG - 2016-03-04 12:01:01 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-04 12:01:01 --> Final output sent to browser
DEBUG - 2016-03-04 12:01:01 --> Total execution time: 0.6315
DEBUG - 2016-03-04 12:01:02 --> Config Class Initialized
DEBUG - 2016-03-04 12:01:02 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:01:02 --> Utf8 Class Initialized
DEBUG - 2016-03-04 12:01:02 --> UTF-8 Support Enabled
DEBUG - 2016-03-04 12:01:02 --> URI Class Initialized
DEBUG - 2016-03-04 12:01:02 --> Router Class Initialized
ERROR - 2016-03-04 12:01:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2016-03-04 15:13:59 --> Config Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Hooks Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Utf8 Class Initialized
DEBUG - 2016-03-04 15:13:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-04 15:13:59 --> URI Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Router Class Initialized
DEBUG - 2016-03-04 15:13:59 --> No URI present. Default controller set.
DEBUG - 2016-03-04 15:13:59 --> Output Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Security Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Input Class Initialized
DEBUG - 2016-03-04 15:13:59 --> CRSF cookie Set
DEBUG - 2016-03-04 15:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-04 15:13:59 --> Language Class Initialized
DEBUG - 2016-03-04 15:13:59 --> initiating auth
DEBUG - 2016-03-04 15:13:59 --> Loader Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Controller Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Helper loaded: form_helper
DEBUG - 2016-03-04 15:13:59 --> Helper loaded: url_helper
DEBUG - 2016-03-04 15:13:59 --> Helper loaded: captcha_helper
DEBUG - 2016-03-04 15:13:59 --> Form Validation Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Session Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Helper loaded: string_helper
DEBUG - 2016-03-04 15:13:59 --> Encrypt Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Database Driver Class Initialized
ERROR - 2016-03-04 15:13:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
DEBUG - 2016-03-04 15:13:59 --> Session garbage collection performed.
DEBUG - 2016-03-04 15:13:59 --> Session routines successfully run
DEBUG - 2016-03-04 15:13:59 --> Model Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Model Class Initialized
DEBUG - 2016-03-04 15:13:59 --> Helper loaded: date_helper
DEBUG - 2016-03-04 15:13:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-03-04 15:14:00 --> Model Class Initialized
DEBUG - 2016-03-04 15:14:00 --> File loaded: application/views/commons/header.php
DEBUG - 2016-03-04 15:14:00 --> File loaded: application/views/commons/navigations.php
DEBUG - 2016-03-04 15:14:00 --> File loaded: application/views/login.php
DEBUG - 2016-03-04 15:14:00 --> File loaded: application/views/commons/footer.php
DEBUG - 2016-03-04 15:14:00 --> Final output sent to browser
DEBUG - 2016-03-04 15:14:00 --> Total execution time: 0.2100
