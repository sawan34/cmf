<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-05 00:02:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 00:03:35 --> Severity: Warning  --> mysql_pconnect(): Can't connect to MySQL server on '10.247.3.101' (4) /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 00:03:35 --> Unable to connect to the database
ERROR - 2016-03-05 19:11:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 19:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 19:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 19:12:10 --> Severity: Warning  --> mysql_pconnect(): Can't connect to MySQL server on '10.247.3.101' (4) /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 19:12:10 --> Unable to connect to the database
ERROR - 2016-03-05 19:12:11 --> Severity: Warning  --> mysql_pconnect(): Can't connect to MySQL server on '10.247.3.101' (4) /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 19:12:11 --> Unable to connect to the database
ERROR - 2016-03-05 19:12:38 --> Severity: Warning  --> mysql_pconnect(): Can't connect to MySQL server on '10.247.3.101' (4) /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-05 19:12:38 --> Unable to connect to the database
