<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-07 10:25:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:25:25 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'pubsub'@'10.1.36.116' (using password: YES) /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:25:25 --> Unable to connect to the database
ERROR - 2016-03-07 10:25:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-07 10:25:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:25:40 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'pubsub'@'10.1.36.116' (using password: YES) /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:25:40 --> Unable to connect to the database
ERROR - 2016-03-07 10:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:31:01 --> Severity: Warning  --> ldap_bind(): Unable to bind to server: Can't contact LDAP server /home/sid/nicspace/cbps-subscriber/application/libraries/Ldapauth.php 50
ERROR - 2016-03-07 10:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:31:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:45:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:45:50 --> Severity: Warning  --> ldap_bind(): Unable to bind to server: Can't contact LDAP server /home/sid/nicspace/cbps-subscriber/application/libraries/Ldapauth.php 50
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:50 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-07 10:45:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 10:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 12:43:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 12:43:12 --> Query error: Table 'pubsub.cbps_subs_sessions' doesn't exist
ERROR - 2016-03-07 12:43:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-07 14:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 14:37:27 --> Query error: Table 'pubsub.cbps_subs_sessions' doesn't exist
ERROR - 2016-03-07 14:37:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-07 16:16:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 16:16:35 --> Query error: Table 'pubsub.cbps_subs_sessions' doesn't exist
ERROR - 2016-03-07 23:52:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-07 23:52:40 --> Query error: Table 'pubsub.cbps_subs_sessions' doesn't exist
ERROR - 2016-03-07 23:52:40 --> 404 Page Not Found --> favicon.ico
