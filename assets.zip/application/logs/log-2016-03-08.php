<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-08 11:43:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 11:43:31 --> Query error: Table 'pubsub.cbps_subs_sessions' doesn't exist
ERROR - 2016-03-08 12:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 12:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 12:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:06:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:07:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:07:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:08:04 --> Size  id is >>>>>>>>> 
ERROR - 2016-03-08 13:08:04 --> query is  SELECT *
FROM (`image_dimensions_master`)
WHERE `is_active` =  1
AND `id` =  '9'
ERROR - 2016-03-08 13:08:04 --> row id is >>>>>>>>> 1
ERROR - 2016-03-08 13:08:04 --> row is >>>>>>>>> {"id":"9","width":"250","height":"250","is_active":"1"}
ERROR - 2016-03-08 13:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:08:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:08:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:08:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:08:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:56:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 13:59:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:00:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:03:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:03:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:03:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:03:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:05:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:05:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:09:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:14:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:14:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:14:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:14:42 --> Severity: Notice  --> Undefined property: CI_Loader::$Nodal_model /home/sid/nicspace/cbps-subscriber/application/views/commons/footer.php 4
ERROR - 2016-03-08 14:15:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:15:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:15:51 --> Severity: Notice  --> Undefined property: CI_Loader::$Nodal_model /home/sid/nicspace/cbps-subscriber/application/views/commons/footer.php 4
ERROR - 2016-03-08 14:15:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:17:41 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:18:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:24 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:29 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:19:30 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:13 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:20:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Undefined property: CI_Loader::$ldapauth xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:31 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:20:34 --> Severity: Notice  --> Undefined property: CI_Loader::$Nodal_model Unknown 0
ERROR - 2016-03-08 14:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Undefined property: CI_Loader::$ldapauth xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:14 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:23 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:24:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:24:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:24:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:24:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:24:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined property: Subscription::$ldapauth xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined property: Subscription::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined property: Subscription::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined property: Subscription::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:24:39 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:26:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:26:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:26:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:35:00 --> Severity: Notice  --> Undefined variable: vals /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 123
ERROR - 2016-03-08 14:35:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:35:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:35:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:35:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:36:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:38:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:43:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:43:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined property: Subscription::$ldapauth xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined property: Subscription::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined property: Subscription::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined property: Subscription::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:47 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:43:58 --> Size  id is >>>>>>>>> 
ERROR - 2016-03-08 14:43:58 --> query is  SELECT *
FROM (`image_dimensions_master`)
WHERE `is_active` =  1
AND `id` =  '13'
ERROR - 2016-03-08 14:43:58 --> row id is >>>>>>>>> 1
ERROR - 2016-03-08 14:43:58 --> row is >>>>>>>>> {"id":"13","width":"196","height":"57","is_active":"1"}
ERROR - 2016-03-08 14:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined property: Subscription::$ldapauth xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined property: Subscription::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined property: Subscription::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined property: Subscription::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 14:44:59 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 14:45:04 --> Size  id is >>>>>>>>> 
ERROR - 2016-03-08 14:45:04 --> query is  SELECT *
FROM (`image_dimensions_master`)
WHERE `is_active` =  1
AND `id` =  '8'
ERROR - 2016-03-08 14:45:04 --> row id is >>>>>>>>> 1
ERROR - 2016-03-08 14:45:04 --> row is >>>>>>>>> {"id":"8","width":"336","height":"280","is_active":"1"}
ERROR - 2016-03-08 14:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:45:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:45:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:45:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:45:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:45:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:46:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 14:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:03:38 --> Severity: Notice  --> Undefined variable: captcha /home/sid/nicspace/cbps-subscriber/application/views/login.php 31
ERROR - 2016-03-08 15:03:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:03:51 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:04:04 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:02 --> Severity: Notice  --> Undefined variable: captcha Unknown 0
ERROR - 2016-03-08 15:05:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Undefined property: CI_Loader::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Undefined property: CI_Loader::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Undefined variable: blocked_email xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:03 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:28 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:05:28 --> N;
ERROR - 2016-03-08 15:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:31 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:05:31 --> N;
ERROR - 2016-03-08 15:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:33 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:05:33 --> N;
ERROR - 2016-03-08 15:05:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:36 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:05:36 --> N;
ERROR - 2016-03-08 15:05:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:05:40 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:05:40 --> N;
ERROR - 2016-03-08 15:05:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:06:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:06:27 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:06:27 --> N;
ERROR - 2016-03-08 15:06:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:07:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:10 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:21 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Undefined variable: auth_response Unknown 0
ERROR - 2016-03-08 15:07:22 --> N;
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:22 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:23 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:51 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:53 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Undefined variable: auth_response Unknown 0
ERROR - 2016-03-08 15:07:55 --> N;
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:55 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:56 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:07:58 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:02 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:03 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:07 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Undefined variable: con xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Warning  --> ldap_error() expects parameter 1 to be resource, null given xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Undefined property: Auth::$CI xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Undefined property: Auth::$cache xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Undefined variable: subscriptions xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Undefined variable: blocked_durration xdebug://debug-eval 1
ERROR - 2016-03-08 15:08:08 --> Severity: Notice  --> Trying to get property of non-object xdebug://debug-eval 1
ERROR - 2016-03-08 15:10:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:10:28 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:10:28 --> N;
ERROR - 2016-03-08 15:10:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:10:29 --> Severity: Notice  --> Undefined variable: login_attempts /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 123
ERROR - 2016-03-08 15:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:06 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:11:06 --> N;
ERROR - 2016-03-08 15:11:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:08 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:11:08 --> N;
ERROR - 2016-03-08 15:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:09 --> Severity: Notice  --> Undefined variable: auth_response /home/sid/nicspace/cbps-subscriber/application/controllers/auth.php 106
ERROR - 2016-03-08 15:11:09 --> N;
ERROR - 2016-03-08 15:11:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:11:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-03-08 15:43:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /home/sid/nicspace/cbps-subscriber/system/database/drivers/mysql/mysql_driver.php 92
