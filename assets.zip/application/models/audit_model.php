<?php if ( ! defined('BASEPATH')) exit('No direct script
  access allowed');

class Audit_model extends CI_Model {
  function __construct() {
    parent::__construct();   
    $this->load->helper('date');
  }
  
  public function log($ip, $email, $action) {
    $this->db->insert('audit_trail', array('ip'=>$ip,'email'=>$email, 'action'=>$action));
  }
}