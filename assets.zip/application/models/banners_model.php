<?php

if (!defined('BASEPATH'))
  exit('No direct script
    access allowed');

class Banners_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function get_active_banner_sizes() {
    return $this->db->from('image_dimensions_master')->where('is_active', 1)->get()->result();
  }

  public function is_active_banner_size($size_id) {
    log_message('error', 'Size  id is >>>>>>>>> ' . is_int($size_id));
    if(!is_numeric($size_id)){
      return false;
    }
    $query = $this->db->from('image_dimensions_master')->where('is_active', 1)->where('id', $size_id);
    $row =  $query->get()->row();
    log_message('error', 'query is  ' . $this->db->last_query());    
    log_message('error', 'row id is >>>>>>>>> ' . isset($row->id));
    log_message('error', 'row is >>>>>>>>> ' . json_encode($row));
    
    if(isset($row->id)){
      return true;
    }else{
      return false;
    }
  }
  
  public function get_live_banner_by_channel($channel_id){
    $row =  $this->db->from('banners')->where('is_active', 1)->where('channel_id', $channel_id)->get()->row();
    return $row;

  }

}
