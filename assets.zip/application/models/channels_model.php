<?php

if (!defined('BASEPATH'))
  exit('No direct script
  access allowed');

class Channels_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  public function get_all_channels() {
    $sql = "select * from channels;";
    $channels = $this->db->query($sql, array())->result();
    return $channels;
  }
  
  public function get_channel($channel_id){
    if(!is_numeric($channel_id)){
      return FALSE;
    }
    $channel = $this->db->from('channels')->where('id',$channel_id)->get()->row();
    return $channel;
  }
  
  public function get_channel_image_urls($channel_id){
    $urls= $this->db->from('channel_image_urls')->where('channel_id',$channel_id)->get()->result();
    return $urls;
  }
  
  public function get_image_url_by_id($id){
    $url= $this->db->from('channel_image_urls')->where('id',$id)->get()->row();
    return $url;
  }

//=====  
  public function get_live_banner($channel_id){
    $sql = 'select * from banners where channel_id = ? and is_active = 1';
    $banner = $this->db->query($sql, array($channel_id))->row();
    return $banner;
  }

  
  public function get_banners_count() {
    $sql = "SELECT count(*) as c FROM banners;";
    $count = $this->db->query($sql, array())->row();
    return $count->c;
  }
  
  public function get_published_channels($user_id){
    $sql = "select c.* from channel_owners co inner join channels c on co.channel_id=c.id where co.user_id=? ";
    $channels = $this->db->query($sql, array($user_id))->result();
    return $channels;    
  }
  
  public function get_subscribed_channels($user_id){
    $sql = "select c.*, cs.*, c.last_updated as channel_last_updated from channel_subscriptions cs inner join channels c on cs.channel_id=c.id where cs.user_id=? ";
    $channels = $this->db->query($sql, array($user_id))->result();
    return $channels;    
  }
  
  public function get_recommended_channels($user_id){
    $sql = "select c.* from channels c where id not in (select distinct channel_id from channel_subscriptions where user_id = ?)";
    $channels = $this->db->query($sql, array($user_id))->result();
    return $channels;    
  }
  

  
  
  public function get_subscribers_by_channels($channel_ids){
    if(count($channel_ids)==0){
      return array();
    }
    $channels = $this->db->from('channel_subscriptions')->where_in('channel_id',$channel_ids)->get()->result();
    return $channels;    
  }

  public function get_channels_count() {
    $sql = "SELECT count(*) as c FROM channels;";
    $count = $this->db->query($sql, array())->row();
    return $count->c;
  }

  public function get_images_count() {
    $sql = "SELECT count(*)as c FROM images;";
    $count = $this->db->query($sql, array())->row();
    return $count->c;
  }

  public function get_subscriptions_count() {
    $sql = "SELECT count(*) as c FROM subscriptions;";
    $count = $this->db->query($sql, array())->row();
    return $count->c;
  }

  public function get_banners() {
    $sql = "SELECT * FROM banners;";
    $count = $this->db->query($sql, array())->row();
    return $count;
  }

  public function update_channel($channel) {
    $this->db->update('channels', $channel, array('id' => $channel['id']));
  }

  public function subscribe($subscription) {
    $this->db->insert('channel_subscriptions', $subscription);
  }

  public function unsubscribe($subscription) {
    $this->db->delete('subscriptions', $subscription);
  }

}

