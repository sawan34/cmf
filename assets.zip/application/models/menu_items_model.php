<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Menu_items_model extends CI_Model {

	public $variable;

	public function __construct()
	{
		parent::__construct();
        $this->load->helper('date');		
	}
    public function fetch_all_menu(){
    	$menus = $this->db->select('*')->from('menu_items')->get()->result();
    	return $menus;

    }
}

/* End of file menu_items.php */
/* Location: ./application/models/menu_items.php */