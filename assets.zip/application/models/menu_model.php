<?php
class Menu_model extends CI_Model {

	public function all($menuType)
	{
		//return $this->db->get("menu")->where('menu_type',$menuType)->result_array();
		return $this->db->select('*')->where('menu_type',$menuType)->get("menu")->result_array();
	}

	public function create(){
		
	}

}