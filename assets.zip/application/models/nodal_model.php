<?php if ( ! defined('BASEPATH')) exit('No direct script
  access allowed');

class Nodal_model extends CI_Model {
  function __construct() {
    parent::__construct();   
  }
  public function get_officers() {
    $vocabs = $this->db->from('nodal_offecers')->get()->result();
    return $vocabs;
  }  
}