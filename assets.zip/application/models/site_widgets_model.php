<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Site_widgets_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->helper('date');
    }

    function get_widget_details($widget_id, $site_id) {
        return $this->db->from('site_widgets')->where('widget_id', $widget_id)->where('site_id', $site_id)->get()->result();
    }
    function get_menu_details($widget_id, $site_id,$menu_type){
     return $this->db->from('site_widgets')->where('widget_id', $widget_id)->where('site_id', $site_id)->where('widget_area_id',$menu_type)->get()->result();   
    } 
    function create($site) {
        $this->db->insert('site_widgets', $site);
        $site_widget_id = $this->db->insert_id();
        return $site_widget_id;
    }

    function update($site_widget_id, $widget_data) {
        $this->db->where('id', $site_widget_id);
        return $this->db->update('site_widgets', array('widget_data' => $widget_data));
    }

    function delete($site_widget_id) {
        $this->db->where('widget_id', $site_widget_id);        
        $this->db->delete('site_widgets');
    }

}
