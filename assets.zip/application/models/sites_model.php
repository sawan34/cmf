<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Sites_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->helper('date');
    }

    public function create($site) {
        $this->db->insert('sites', $site);
        $site_id = $this->db->insert_id();
        return $site_id;
    }

    function update($site_id, $site) {
        $this->db->where('site_id', $site_id);
        return $this->db->update('sites', $site);
    }

    function get_user_sites($user_id) {
        return $this->db->from('sites')->where('user_id', $user_id)->get()->result();
    }

}
