<?php if ( ! defined('BASEPATH')) exit('No direct script
  access allowed');

class Subscriptions_model extends CI_Model {
  function __construct() {
    parent::__construct();   
  }
  
  public function get_user_subscriptions($user_id) {
    return $this->db->from('user_subscriptions')->where('user_id', $user_id)->get()->result();
  }
  
  public function get_subscription_by_user($channel_id, $user_id){
    return $this->db->from('user_subscriptions')->where('user_id', $user_id)->where('channel_id', $channel_id)->get()->row();
  }
  
  public function get_subscription($id) {
    return $this->db->from('user_subscriptions')->where('id', $id)->get()->row();
  }

  
  public function subscribe_user($subscription){
    $this->db->insert('user_subscriptions', $subscription); 
  }
  
  public function get_subscription_by_subscription_code($subscription_code){
    return $this->db->from('user_subscriptions')->where('subscription_code', $subscription_code)->get()->row();
  }

}