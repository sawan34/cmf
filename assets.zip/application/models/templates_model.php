<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Templates_model extends CI_Model {
  function __construct() {
    parent::__construct();   
    $this->load->helper('date');
  }
  
  public function get_all_templates() {
    $sql = "select * from templates;";
    $templates = $this->db->query($sql, array())->result();
    return $templates;
  }
  
  public function create($site) {
    $this->db->insert('sites',$site);
  }
  
  function update($site_id,$site)
  {    
    $this->db->where('site_id', $site_id);
    return $this->db->update('sites', $site);
  }
}