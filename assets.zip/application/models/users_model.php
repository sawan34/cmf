<?php if ( ! defined('BASEPATH')) exit('No direct script
  access allowed');

class Users_model extends CI_Model {
  function __construct() {
    parent::__construct();   
  }
  
  public function get_user($id) {
    return $this->db->from('users')->where('id', $id)->get()->row();
  }
  
  public function get_user_by_mail($email) {
    return $this->db->from('users')->where('email', $email)->get()->row();
  }
  
  public function create($user){
    $this->db->insert('users', $user);
  }
  
  public function is_blocked_email($email){
    $record =  $this->db->from('blocked_emails')->where('email', $email)->get()->row();
    if(empty($record)){
      return FALSE;
    }
    return TRUE;
  }
  
  public function block_email($email){
    $this->db->insert('blocked_emails', array('email'=>$email));
  }
  
  //insert into user table
  function insertUser($data)
    {
    return $this->db->insert('users', $data);
  }
  
  //send verification email to user's email id
  function sendEmail($to_email)
  {
    $from_email = 'team@mydomain.com';
    $subject = 'Verify Your Email Address';
    $message = 'Dear User,<br /><br />Please click on the below activation link to verify your email address.<br /><br /> http://www.mydomain.com/user/verify/' . md5($to_email) . '<br /><br /><br />Thanks<br />Mydomain Team';
    
    //configure email settings
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'ssl://smtp.mydomain.com'; //smtp host name
    $config['smtp_port'] = '465'; //smtp port number
    $config['smtp_user'] = $from_email;
    $config['smtp_pass'] = '********'; //$from_email password
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes
    $this->email->initialize($config);
    
    //send mail
    $this->email->from($from_email, 'Mydomain');
    $this->email->to($to_email);
    $this->email->subject($subject);
    $this->email->message($message);
    return $this->email->send();
  }
  
  //activate user account
  function verifyEmailID($key)
  {
    $data = array('status' => 1);
    $this->db->where('md5(email)', $key);
    return $this->db->update('user', $data);
  }
  
}