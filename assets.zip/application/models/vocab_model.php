<?php if ( ! defined('BASEPATH')) exit('No direct script
  access allowed');

class Vocab_model extends CI_Model {
  function __construct() {
    parent::__construct();   
  }
  public function get_vocabs($id) {
    $vocabs = $this->db->select('id, name')->from('vocab')->where('pid', $id)->get()->result();
    return $vocabs;
  }  

  public function get_all_vocabs(){
  	$vocabs = $this->db->select('id, name')->from('vocab')->get()->result();
    return $vocabs;
  }
}