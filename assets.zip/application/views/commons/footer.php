<?php
  $ci =&get_instance();
  $ci->load->database();
  $ci->load->model(array('Nodal_model'));
  $nodal_officers = $ci->Nodal_model->get_officers();
?>
<footer class="footer">
  <div class="container">
    <div class="text-center">
      <ul class="list-group list-inline">
        <li class="list-group-item"><a href="#">Terms & Conditions</a></li>
        <li class="list-group-item devider">|</li>
        <li class="list-group-item"><a href="#">FAQ </a></li>
        <li class="list-group-item devider">|</li>
        <li class="list-group-item"><a href="#">Disclaimers</a></li>
        <li class="list-group-item devider">|</li>
        <li class="list-group-item"><a href="#">Help </a></li>
      </ul>
    </div>
  </div>
</footer>
<div class="modal nodal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" id="gridSystemModalLabel">Nodal Officers List</h3>
      </div>
      <div class="modal-body">
        <table class="table-bordered table-condensed table-striped">
          <tr>
            <th class="col-sm-1">S No</th>
            <th>Name</th>
            <th>Designation</th>
            <th>Ministry</th>
            <th>Contact No</th>
            <th>Email</th>
          </tr>
          <?php foreach ($nodal_officers as $index => $officer) : ?>
            <tr>
              <td><?= $index + 1 ?></td>
              <td><?= $officer->name ?></td>
              <td><?= $officer->designation ?></td>
              <td><?= $officer->ministry ?></td>
              <td><?= $officer->contact_no ?></td>
              <td><?= str_replace('@', '[at]', str_replace(".", '[dot]', $officer->email)) ?></td>           
            </tr>
          <?php endforeach; ?> 
        </table>
      </div>
    </div>
  </div>
</div>

</body>

<script type="text/javascript">
  $(function () {
    var msg = "<?php echo $this->session->flashdata('msg'); ?>";
    if (msg && msg.split(':').length > 1) {
      msg = msg.split(':');
      Msg.show(msg[1], msg[0], 200000);
    }
  });
  $(function () {
    //to conver date
    $('.unix-date').each(function (i, el) {
      $(el).html(moment.unix(el.textContent).fromNow());
    })
  });

</script>
<script type = "text/javascript" >
  (function burstCache() {
    if (!navigator.onLine) {
      document.body.innerHTML = 'Loading...';
      window.location = '/login';
    }
  })();
</script>
<script type="text/javascript">
  $(function () {
//    listing nodal officer
    $('a.nodal').on('click', function (e) {
      e.preventDefault();
      $('.modal.nodal').modal('toggle');
    });
  });
</script>
</html>