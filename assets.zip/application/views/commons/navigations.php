<header>
    <div class="container header">
        <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
            <ul class="list-group list-unstyled list-inline logos">                
                <li class="list-group-item"><a href="/"><img src="/assets/images/cmf-logo.png"></a></li>
            </ul>
        </div>
        <div class="col-lg-3 col-md-2 col-sm-2 col-xs-4 text-right">
            <ul class="list-inline">
                <li><span class="center-block"></span><a href="http://www.digitalindia.gov.in/"><img src="/assets/images/digital-india.png"></a></li>
            </ul>
        </div>
        <div class="col-lg-3 col-md-5 col-sm-5 col-xs-8 text-right">
            <ul class="list-group list-unstyled list-inline links">
                <li class="list-group-item"><a href="/contact-us">Contact Us</a></li>
            </ul>
        </div>
    </div>
</header>