<?php
  $user = $this->session->userdata('user');
?>
<section>
  <div class="container-fluid inner-banner-section">
    <div class="container">
      <div class="pull-right">
        <span class="text-smal btn btn-link text-grey text-no-decoration">Welcome!  <?=$user->email?></span>
        <a href="/logout" class="btn btn-sm btn-success btn-borderd">Logout</a>
      </div>
    </div>
  </div>
</section>