<!-- Content Section Starts -->

<div class="content-section">
  <div class="container">
    <h2 class="heading1 borderd-bottom">Feedback</h2>
    <div class="row">

      <div class="col-xs-12">

        <div class="login-form subscribe"> 

          <h4>Feedback Details:</h4>

          <p><strong>Centralised Banner Publishing System</strong> <br>National Informatics Centre<br>
            Department of Electronics & Information Technology<br>
            Ministry of Communications & Information Technology<br>
            A-Block, CGO Complex, Lodhi Road<br>
            New Delhi - 110 003 India<br>
            cbps[at]nic[dot]in</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Content Section Ends -->