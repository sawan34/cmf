<div class="content-section">
    <div class="container">
        <h2 class="heading1">Your websites:</h2>
        <div class="page-tab">     
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="home">
                    <div class="row">
                        
                            <a class="btn btn-lg btn-subscribe pull-right" href="/builder/create">Create Website</a>

                        <?php foreach ($sites as $site): ?>
                            <div class="col-md-4 subscribe-effect">
                                <!--<img src="/assets/images/">-->
                                <div class="subscription">
                                    <span class="subscription-text">Subscribe channel for <?php //echo $site->name   ?> banners</span>                  
                                    <?php if ($site->isFinal == 1): ?>
                                        <a class="btn btn-lg btn-subscribe" href="/sites/<?php echo $site->id; ?>">Already submitted!</a>                    
                                    <?php else : ?>
                                        <a class="btn btn-lg btn-subscribe" href="/sites/<?php echo $site->id; ?>">Edit Now!</a>                    
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>             
                    </div>
                </div>        
            </div>
        </div>
    </div>
</div>