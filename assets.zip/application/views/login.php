<?php
  $has_captch = $this->session->userdata('captcha');
?>
<section>
  <link href="/assets/css/flexslider.css" rel="stylesheet" media="all">
  <div class="container-fluid banner-section">
    <div class="container">
      <div class="col-lg-6 col-md-6 col-sm-7">
        <h1 class="heading1">SaaS Configuration Portal</h1>
        <p>Using SaaS Configuration Portal you can develop your website in 2 minutes. <br/>
            Just do a singup and fill all the mandatory details. Once your account is created, you can create your website.
            
        </p>
      </div>

      <div class="col-lg-6 col-md-6 col-sm-7">
        <div class="login-form">
          <h2 class="heading1">Login to SaaS Configuration Portal</h2>
          <?php echo form_open('login') ?>
          <span class="text-warning text-capitalize"> <?php echo $this->session->flashdata('msg')?></span>
          <div class="form-group">
            <input type="email" name="username" class="form-control" id="username" autofocus 
                   placeholder="Enter your NIC accounts eg: abc@gov.in" autocomplete="off">
            <span class="text-warning"><?php echo form_error('username'); ?></span>
          </div>
          <div class="form-group">
            <input type="password" name="password" class="form-control" id="password" autocomplete="off" placeholder="Password">
            <span class="text-warning"><?php echo form_error('password'); ?></span>

          </div>
          <?php if ($has_captch):?>          
          <div class="form-group">
            <?= $captcha['image'] ?>
            <input type="text" name="captcha" class="form-control col-sm-12" id="captcha" autocomplete="off" placeholder="Enter Captcha Above">
          </div>
          <?php endif;?>

          <button type="submit" class="btn btn-block btn-subscribe">Sign In</button>
          </form>
        </div>
      </div>



    </div>
  </div>
</section>
<div class="content-section">
  <div class="container">
    <div class="container carousel-container">
      <div id="flexCarousel" class="flexslider carousel">
        <ul class="slides">
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner1.jpg" alt=""></a></li>
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner2.jpg" alt=""></a></li>
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner3.jpg" alt=""></a></li>
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner4.jpg" alt=""></a></li>
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner1.jpg" alt=""></a></li>
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner2.jpg" alt=""></a></li>
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner3.jpg" alt=""></a></li>
          <li><a target="_blank" href="#" title=" "><img src="/assets/images/banner4.jpg" alt=""></a></li>

        </ul>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
  $(document).ready(function (e) {
    // Carousel						
    $('#flexCarousel').flexslider({
      animation: "slide",
      animationLoop: false,
      itemWidth: 206,
      itemMargin: 10,
      minItems: 2,
      maxItems: 6,
      slideshow: 1,
      move: 1,
      controlNav: true,
      directionNav: false,
      start: function (slider) {
        $('body').removeClass('loading');
        if (slider.pagingCount === 1)
          slider.addClass('flex-centered');
      }
    });
   
  });
</script>