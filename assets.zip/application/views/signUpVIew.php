
<section>
<?php form_open("signup");?>
<form action="" method="POST" role="form">
  <legend>Form title</legend>
<div class="form-group">
  	<label for="input" class="col-sm-2 control-label">:</label>
  	<div class="col-sm-10">
  		<input type="email" name="email" id="input" class="form-control" value="" required="required" title="">
  	</div>
  	            <span class="text-warning"><?php echo form_error('email'); ?></span>

  </div>

  <div class="form-group">
  	<label for="input" class="col-sm-2 control-label">:</label>
  	<div class="col-sm-10">
  		<input type="text" name="name" id="input" class="form-control" value="" >
  	</div>
  	            <span class="text-warning"><?php echo form_error('name'); ?></span>

  </div>

  <div class="form-group">
  	<label for="input" class="col-sm-2 control-label">:</label>
  	<div class="col-sm-10">
  		<input type="password" name="password1" id="input" class="form-control" required="required" title="">
  	</div>
  	            <span class="text-warning"><?php echo form_error('password1'); ?></span>

  </div>

  <div class="form-group">
  	<label for="input" class="col-sm-2 control-label">:</label>
  	<div class="col-sm-10">
  		<input type="password" name="password2" id="input" class="form-control" required="required" title="">
  	</div>
  	            <span class="text-warning"><?php echo form_error('password2'); ?></span>

  </div>





  

  <button type="submit" class="btn btn-primary">Submit</button>
</form>

</section>