<!-- Content Section Starts -->
<?php
$this->load->helper('array');
$this->load->helper('date');
$this->load->helper('string');
$channel_image_urls = associate_array_with_prop($channel_image_urls, 'image_dimension_id');
$banner_sizes = associate_array_with_prop($banner_sizes, 'id');
$selected_size = $banner_sizes[$subscription->image_dimension_id];
$image_url = $channel_image_urls[$subscription->image_dimension_id]->image_url;


?>

<style>
  .code-wrap{
      word-wrap: break-word;
      background-color: wheat;
      padding: 20px;
      margin-top: 10px;
  }
</style>

<div class="content-section">
  <div class="container">
    <h2 class="heading1 borderd-bottom">Creator/Publisher: <?= $channel->name ?> <span class="pull-right text-small">Created : <span class="unix-date"><?= $channel->created_at ?></span></span></h2>
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-5 col-xs-12">
        <h4 class="heading2 text-green">Your Chosen Banner</h4>
        <div class="image-box"> <img src="/assets/uploads/<?php echo $channel_image_urls[$subscription->image_dimension_id]->image_url ?>"> <a href="#" class="zoom-icon" data-toggle="modal" data-target="#myModal1"></a> </div>
      </div>
      <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12 image-subscribe">
<!--        <h3 class="heading3"><?= $live_banner->name ?></h3>-->
        <div class="login-form subscribe">
          <span class="text-info hidden"><a href="<?=$subscription->linked_url?>" target="_blank"><?=$subscription->linked_url?></a> has been successfully subscribed to the <b><?= $channel->name ?></b> Channel and now registered to the NIC mail service.
            From now, this site would be reflected with new banners as and when published by the Channel (e.g.:PMO) and would be periodically updated and notified to the registered mobile <b><?= $user->contact_no ?></b>  and email <strong><?= $user->email ?></strong>.
          </span>
          <p class="text-info">
            You have successfully generated integration code for channel <?= $channel->name ?>, <strong><a data-clipboard-target="#copy-me" class="cpy" style="cursor: pointer"> Click here </a></strong> to Copy Integration Code and subscribe your site (<a target="_blank " href="<?=$subscription->linked_url?>"><?=$subscription->linked_url?></a>) to channel(<?= $channel->name ?>). 
          </p>
<!--          <span class="text-bold">#<?= $live_banner->name ?></span> | <span class="text-bold"> <?= $channel->name ?> </span> 
          <span  class="center-block text-bold"> URL: <a href="<?= $live_banner->target_url ?>" class="text-grey"><?= $live_banner->target_url ?></a></span> 
          <span class="heading2 text-small text-bold text-green center-block text-uppercase">Has Been Subscribed On : <span class="text-grey"><?= unix_to_human($subscription->created_at) ?></span> </span> 
          <span class="text-bold center-block"><strong>Size:</strong> <?= $selected_size->width ?>x<?= $selected_size->height ?> Pixel</span>-->
          <div class="row clearfix final-subscribe">

            <div class="col-sx-4" ><a data-clipboard-target="#copy-me" class="cpy btn btn-subscribe">Copy Code & Integrate in Site</a></div>

            <div class="col-xs-12 code-wrap">
              <code id="copy-me" type="text" readonly> &lt;img src=&quot;<?=$this->config->item('base_url')?>assets/uploads/<?=$image_url?>&quot; id=&quot;_<?=$subscription->subscription_code?>&quot; onclick=&quot;javascript:window.open(&#39;<?=$this->config->item('base_url')?>aff/<?=$subscription->subscription_code?>&#39;)&quot; style=&quot;cursor:pointer&quot; onload=&quot;javascript:(function(){if(typeof _done == &#39;undefined&#39; || !_done){this.setAttribute(&#39;src&#39;, this.getAttribute(&#39;src&#39;)+&#39;?&#39;+Math.floor((Math.random() * 100) + 1)); _done=true;}}).call(this)&quot; &gt;</code>
            </div>            
            
          </div>
          <p class="text-info">
            <br>
            <span>Few Benfits of subscription-</span>
            <ol class="text-info">
              <li>No worry to manage banner updates, Our system will take care of it.</li>
              <li>Same size Banner on every update.</li>
              <li>You will receive notification by mail (<a href="mailto:<?= $user->email ?>"><?= $user->email ?></a>) and SMS( <b><?= $user->contact_no ?></b> ) for each updates in channel.</li>
            </ol>
          </p>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
  $(function(){
    var clipboard = new Clipboard('.cpy');
    clipboard.on('success', function(e) {
//      console.info('Action:', e.action);
//      console.info('Text:', e.text);
//      console.info('Trigger:', e.trigger);
      e.clearSelection();
      $('.help-modal').modal('toggle');
//      alert('Code Copied, please paste it in your Site\'s HTML !!');
    });
  })
</script>

<!-- Content Section Ends -->

<!-- Modal -->
<div class="modal fade custom-model" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: <?= $selected_size->width ?>x<?= $selected_size->height ?> pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets/uploads/<?php echo $channel_image_urls[$subscription->image_dimension_id]->image_url ?>"> </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal help-modal fade"  tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center text-capitalize" id="gridSystemModalLabel">Embedding code in WebSite !!!</h4>
      </div>
      <div class="modal-body"> 
        <blockquote class="bg-primary">
          <p>
            You have successfully copied integration code, A few more steps to integrate code in your site .
          </p>
        </blockquote>        
        <hr/>        
        <dl class="text-muted">
          <dt>1. Open Page Source Code</dt>
          <dd>Open your site's html code with your preferred editor like Notepad ++.</dd>
          <br>
          <dt>2. Choose Location of banner</dt>
          <dd>In your site's HTML source code Identify the location where you want to place the banner.</dd>
          <br>
          <dt>3. Copy & Paste HTML snippet</dt>
          <dd>Paste the code which you just copied at identified place.</dd>
          <br>
          <dt>4. Verify if code is working fine</dt>
          <dd>Open the Site in Browser, and check if your subscribed channel's banner is visible.</dd>
        </dl>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Got It, Close !!</button>        
      </div>
    </div>
  </div>
</div>
