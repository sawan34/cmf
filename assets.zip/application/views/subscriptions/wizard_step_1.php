<?php
  $banner_sizes = associate_array_with_prop($banner_sizes, array('width', 'height'));
  $channel_image_urls = associate_array_with_prop($channel_image_urls, 'image_dimension_id');
?>
<?php if(count($channel_image_urls) > 0):?>
<div class="content-section">
  <div class="container">
    <h2 class="heading1 borderd-bottom">Creator/Publisher: <?=$channel->name?> <span class="pull-right text-small">Created : <span class="unix-date"><?= $channel->created_at ?></span></span></h2>
    <div class="note"> <span class="text-red">NOTE *</span> <span><img src="/assets/images/ico-zoom1.png"> <strong> View Actual Size</strong></span> <span><img src="/assets/images/ico-tick2.png"> <strong>Choose this banner</strong></span> </div>
    <h3 class="heading2">All Available Banner Sizes</h3>
    <div class="row banner-size-boxes">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="image-banner-wraper"> <span class="img-size">1800x450 pixels</span> <img src="/assets/uploads/<?php echo $channel_image_urls[$banner_sizes['1800:450']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal1"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
        <div class="image-banner-wraper"> <span class="img-size">728x90 pixels</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['728:90']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal2"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon" ><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <div class="image-banner-wraper"> <span class="img-size">336x280 pixels</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['336:280']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal3"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-4">
        <div class="image-banner-wraper"> <span class="img-size">250x250 pixels</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['250:250']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal4"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-4">
        <div class="image-banner-wraper"> <span class="img-size">240x120 pixels</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['240:120']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal5"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
        <div class="image-banner-wraper"> <span class="img-size">220x80 pixels</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['220:80']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal6"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
        <div class="image-banner-wraper"> <span class="img-size">200x55 pixels</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['200:55']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal7"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-4">
        <div class="image-banner-wraper"> <span class="img-size">196x57 px</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['196:57']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal8"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
        <div class="image-banner-wraper"> <span class="img-size">130x35 px</span> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['130:35']->id]->image_url; ?>">
          <div class="image-banner-details">
            <div class="image-banner-icons"> <a href="#" class="image-banner-icon" data-toggle="modal" data-target="#myModal9"><img src="/assets/images/ico-zoom.png"></a> <a href="#" class="image-banner-icon"><img src="/assets/images/ico-tick.png"></a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Content Section Ends -->

<!-- Models for the image popups -->
<!-- Modal -->
<div class="modal fade custom-model" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 1800x450 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['1800:450']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['1800:450']->id?>'>Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->

<div class="modal fade custom-model" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 728x90 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['728:90']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['728:90']->id?>' >Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade custom-model" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 336 x 280 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['336:280']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['336:280']->id?>'>Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade custom-model" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 250 x 250 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['250:250']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['250:250']->id?>'>Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade custom-model" id="myModal5" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 240x120 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['240:120']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['240:120']->id?>' >Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade custom-model" id="myModal6" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 220x80 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['220:80']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['220:80']->id?>'>Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade custom-model" id="myModal7" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 200x55 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['200:55']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['200:55']->id?>'>Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade custom-model" id="myModal8" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 196x57 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['196:57']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary select " data-dimension='<?= $banner_sizes['196:57']->id?>'>Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade custom-model" id="myModal9" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h5 class="modal-title" id="gridSystemModalLabel">Size: 130x35 pixels</h5>
      </div>
      <div class="modal-body"> <img src="/assets//uploads/<?php echo $channel_image_urls[$banner_sizes['130:35']->id]->image_url; ?>"> </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" data-dimension='<?= $channel_image_urls[14]->id?>' class="btn btn-primary select" data-dimension='<?= $banner_sizes['130:35']->id?>'>Select The Banner</button>
      </div>
    </div>
  </div>
</div>
<?php echo form_open('') ?>
  <input type="hidden" id="image" name="banner-size" value=""/>
</form>
<?php else :?>
  <div class="content-section">
    <div class="container">
      <h3> No banners For you <small> <a href="/">Return to Home</a></small> </h3>
    </div>
  </div>
  
<?php endif;?>


<!-- Models for the image popups -->

<script type="text/javascript">
  $(function(){
    $('.select').click(function(){
      var dimension = $(this).data('dimension');
      $('#image').val(dimension);
      $('form').submit();
    });
  })
</script>
