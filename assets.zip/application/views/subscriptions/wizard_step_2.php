<?php
$this->load->helper('array');
$channel_image_urls = associate_array_with_prop($channel_image_urls, 'image_dimension_id');
$banner_sizes = associate_array_with_prop($banner_sizes, 'id');
$selected_banner_size = $banner_sizes[$banner_size];
$image = $channel_image_urls[$banner_size];
?>

<!-- Content Section Starts -->
<div class="content-section">  
  <div class="container">
    <h2 class="heading1 borderd-bottom">Creator/Publisher: <?= $channel->name ?> <span class="pull-right text-small">Created : <span class="unix-date"><?= $channel->created_at ?></span></span></h2>
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-5 col-xs-12">
        <h4 class="heading2 text-green">Your Chosen Banner</h4>
        <div class="image-box"> <img src="/assets/uploads/<?= $image->image_url ?>"> <a href="#" class="zoom-icon" data-toggle="modal" data-target="#myModal1"></a> </div>
        <div class="clearfix image-caption"> <span class="pull-left">Size: <?= $selected_banner_size->width ?>x<?= $selected_banner_size->height ?>pixels</span> <span class="pull-right"><a href="" class="btn btn-sm btn-default">Change Banner</a></span> </div>
      </div>
      <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12 image-subscribe">
        <h3 class="heading3"><?= $live_banner->name ?></h3>

        <?php echo form_open('',  array('class' => 'login-form subscribe')) ?>                
          
          <div class="form-group clearfix" id='department'>
            <label class="col-sm-4 control-label">Name of Ministry/ Department/ Organisation</label>
            <input type="hidden" name="org" value="-1"/>
            <div class="col-sm-8">
              <select class="form-control first org" placeholder=''></select>
              <span class="help-block"> Start typing to get your department/Organization/Ministry</span>
              <span class="text-warning"><?php echo form_error('org'); ?></span>
            </div>
            <div class="hidden col-sm-offset-4 col-sm-8">
              <select class="form-control org" placeholder=''></select>
              <span class="help-block"> Start typing to get your department/Organization/Ministry</span>
              
            </div>
            <div class="hidden col-sm-offset-4 col-sm-8">
              <select class="form-control org" placeholder=''></select>
              <span class="help-block"> Start typing to get your department/Organization/Ministry</span>
              
            </div>
          </div> 
          <div class="form-group clearfix">
            <label for="inputEmail3" class="col-sm-4 control-label">Enter URL of web page where you wish to place the Banner</label>
            <div class="col-sm-8">
              <input type="text" class="form-control" id="" autocomplete="off" name="linked-url" placeholder="url (eg: http://abc.gov.in)" value="<?php echo set_value('linked-url'); ?>">
              <span class="help-block">Type your page's url (eg: http://abc.gov.in)</span>
              <span class="text-warning"><?php echo form_error('linked-url'); ?></span>
            </div>
          </div>
          <div class="form-group clearfix">
            <label for="inputEmail3" class="col-sm-4 control-label"></label>
            <div class="col-sm-8">
              <button type="submit" class="btn btn-block btn-subscribe">Subscribe</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<script type="text/javascript">
  $(function ($) {
    debugger;
    (function vocabHandler() {
      var org = $('input:hidden[name=org]');
      var renderVocab = function (data) {
        data = data.data;
        var html = [];
        html.push('<option value=\'-99\'>' + ' --Select One-- ' + '</option>');
        jQuery.each(data, function (key, val) {
          html.push('<option value=' + val.id + '>' + val.name + '</option>');
        });
        html = html.join('');
        $(this).html(html).focus();
        //scrolling it in view
        $(this).get(0).scrollIntoView();
//        $(this).trigger('change');
      }
      $('select.org').on('change', function (e) {
        org.val($(this).val());
        var thisDropDown = $(this);
        var thisDropDownContainer = thisDropDown.parent().closest('div');
        var nextDropDownContainers = thisDropDownContainer.nextAll('div');
        /*hide all next*/
        nextDropDownContainers.addClass('hidden');
        debugger;
        loadVocabs(org.val(), function (data) {
          debugger;
          if (data.length > 0) {
            renderVocab.apply(thisDropDownContainer.next('div').removeClass('hidden').find('select'), [{'data': data}]);
          }
        });
      });

      loadVocabs(org.val(), function (data) {
        renderVocab.apply($('select.first'), [{'data': data}]);
      });
    })();    

    function loadVocabs(id, callback) {
      $.ajax({
        url: '/vocab/' + id,
        type: 'GET',
        success: function (data) {
          users = data;
          callback(data);
        },
        error: function () {
          console.log('Something went wrong')
        }
      });
    };
  });
</script>
