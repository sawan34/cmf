<?php
  $this->load->helper('array');
  $channel_image_urls = associate_array_with_prop($channel_image_urls, 'image_dimension_id');  
?>

<div class="content-section">
  <div class="container">
    <h2 class="heading1 borderd-bottom">Creator/Publisher: <?= $channel->name ?> <span class="pull-right text-small">Created on: <?= $channel->created_at ?></span></h2>
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-5 col-xs-12">
        <h4 class="heading2 text-green">Your Chosen Banner</h4>
        <div class="image-box"> <img src="/assets/uploads/<?php echo $channel_image_urls[$subscription->image_dimension_id]->image_url  ?>"> <a href="#" class="zoom-icon" data-toggle="modal" data-target="#myModal1"></a> </div>
      </div>
      <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12 image-subscribe">
        <h3 class="heading3"><?=$live_banner->name?></h3>
        <div class="login-form subscribe"> <span class="text-bold">#<?=$live_banner->name?></span> | <span class="text-bold"><?=$channel->name?></span> <span  class="center-block text-bold"> URL: <a href="<?=$live_banner->target_url?>" target="_blank" class="text-grey"><?=$live_banner->target_url?></a></span> <span class="heading2 text-small text-bold text-green center-block text-uppercase">Has Been Subscribed</span>
          <div class="center-block completion">You are in the final stage of completion. Please <a href="#">copy</a> the code below and <a href="<?=$subscription->linked_url?>" target="_blank">paste</a> it on your website</div>
          <div class="row clearfix final-subscribe">
            <div class="col-xs-6">
              <input type="text" readonly value="<img src='images/img-banner1.jpg'>">
            </div>
            <div class="col-xs-1">OR</div>
            <div class="col-sx-5"><a class="btn btn-subscribe">Copy Code</a></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
