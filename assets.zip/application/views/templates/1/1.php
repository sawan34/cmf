<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="format-detection" content="telephone=no" />
<meta name="description" content="">
<meta name="author" content="">
<link rel="apple-touch-icon" href="/assets/templates/1/assets/images/favicon/apple-touch-icon.png">
<link rel="icon" href="/assets/templates/1/assets/images/favicon/favicon.png">
<title>Home | Department of  Animal Husbandry Dairying &amp; Fisheries</title>

<link href="/assets/templates/1/assets/css/base.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/assets/css/base-responsive.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/assets/css/grid.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/assets/css/font.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/assets/css/font-awesome.min.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/assets/css/flexslider.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/assets/css/megamenu.css" rel="stylesheet" media="all" />
<link href="/assets/templates/1/assets/css/print.css" rel="stylesheet" media="print" />

<!-- Theme styles for this template -->
<link href="/assets/templates/1/theme/css/site.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/theme/css/site-responsive.css" rel="stylesheet" media="all">
<link href="/assets/templates/1/theme/css/ma5gallery.css" rel="stylesheet" type="text/css">

<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
      <script src="/assets/templates/1/assets/js/html5shiv.js"></script>
      <script src="/assets/templates/1/assets/js/respond.min.js"></script>
    <![endif]-->
<!-- Custom JS for this template -->

<script type="text/javascript" src="/assets/templates/1/assets/js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/assets/templates/1/assets/js/framework.js"></script>
<script type="text/javascript" src="/assets/templates/1/assets/js/jquery.flexslider.js"></script>
<script type="text/javascript" src="/assets/templates/1/assets/js/font-size.js"></script>
<script type="text/javascript" src="/assets/templates/1/assets/js/swithcer.js"></script>
<script type="text/javascript" src="/assets/templates/1/theme/js/ma5gallery.js"></script>
<script type="text/javascript" src="/assets/templates/1/assets/js/megamenu.js"></script>
<script type="text/javascript" src="/assets/templates/1/theme/js/site.js"></script>

</head>
<body>

<header>
    <div class="panel panel-default head-panel ">
     <div class="panel-heading heading-panel">
         
<input type="checkbox" name="my-checkbox" checked data-on-text="Edit Mode" data-off-text="Preview Mode"  data-handle-width ="200"  >
                    <button class="btn btn-default pull-right">Sign Out</button>

     </div>

    </div>
</header>

<div class="wrapper common-wrapper">
	<div class="container common-container">
    	<div class="common-left clearfix">
        	<ul>
            	<li class="gov-india"><a title="National Portal of India, External Link that opens in a new window" href="http://india.gov.in" target="_blank"><span>भारत सरकार</span>GOVERNMENT OF INDIA</a></li>
               <li class="ministry"><a title="Ministry Of Agriculture, External Link that opens in a new window" href="#" target="_blank"><span>कृषि मंत्रालय</span>Ministry Name</a></li>
            </ul>
        </div>
        <div class="common-right clearfix">
        	<ul id="header-nav">
           		<li class="ico-skip"><a title="Skip to main content" href="#skipCont"></a></li>
            	<li class="ico-accessibility"><a title="Accessibility Dropdown" id="toggleAccessibility" href="javascript:void(0);"></a>
                	<ul>
                     <li> <a href="javascript:void(0);" title="Increase font size" onClick="set_font_size('increase')">A<sup>+</sup></a> </li>
                        <li> <a href="javascript:void(0);" title="Reset font size" onClick="set_font_size('')">A<sup>&nbsp;</sup></a> </li>
                        <li> <a href="javascript:void(0);" title="Decrease font size" onClick="set_font_size('decrease')">A<sup>-</sup></a> </li>
                        <li> <a title="High Contrast" class="high-contrast dark" href="javascript:void(0);">A</a> </li>
                        <li> <a title="Normal Contrast" class="high-contrast light" href="javascript:void(0);">A</a> </li>
                     
                    </ul>
                </li>
                <li class="ico-social"><a title="Social Media's" id="toggleSocial" href="javascript:void(0);"></a>
                <ul>	
                  <li><a href="#" target="_blank"><img src="/assets/templates/1/assets/images/ico-facebook.png" alt="Facebook, External Link that opens in a new window"></a></li>
                  <li><a href="#" target="_blank"><img src="/assets/templates/1/assets/images/ico-twitter.png" alt="Twitter, External Link that opens in a new window"></a></li>
                  <li><a href="#" target="_blank"><img src="/assets/templates/1/assets/images/ico-youtube.png" alt="youtube, External Link that opens in a new window"></a></li>
                </ul>
                </li>
               
                <li class="ico-site-search"><a title="Site Search" id="toggleSearch" href="javascript:void(0);"></a>
                	<ul class="search-drop">
                        <li>
                        <a></a>
                          <input type="text" placeholder="Search">
                            <input type="submit" value="go" class="bttn-search">
                        </li>
                    </ul>
                </li>
                <li class="ico-sitemap"><a title="Sitemap" href="javascript:void(0);"></a></li>
                <li class="hindi"><a title="Link to Hindi version" href="javascript:void(0);">हिन्दी</a></li>
            </ul>
        </div>
    </div>
</div>
<section class="wrapper header-wrapper">
	<div class="container header-container">
    	<h1 class="logo">
        <a href="" id="header-logo" class="editable" widget-title="site title" 
           widget-id = "1" >
           <strong>विभाग का नाम</strong> 
           <span id="site-eng">Department name</span>
         </a>
         </h1>
        
        <div class="header-right clearfix">
            <div class="right-content clearfix">
                <div id="headerimage" class="float-element editable" widget-title="site title" widget-id = "4">
                    <a class="sw-logo" title="" href="#" target="_blank">
                        <img src="/assets/templates/1/assets/images/swach-bharat.png">
                    </a>
                </div>
                <div id="goii" class="float-element editable" widget-title="site title" widget-id = "2">
                    <a class="sw-logo" title="Swachh Bharat, External Link that opens in a new window" href="https://swachhbharat.mygov.in/" target="_blank"><img src="/assets/templates/1/assets/images/swach-bharat.png"></a>
                </div>
            </div>
        </div>
    </div>
</section><!--/.header-wrapper-->


<section class="wrapper mega-nav-wrapper">
<div class="container">
<div id="header-menu" class="menuzord black editable" widget-title="test widget" widget-id="3">
				<ul class="menuzord-menu">
                	 <li class="active"><a href="home.html"><i class="fa fa-home"></i></a></li>
      				<li><a href="#">About Us</a></li>
                    <li><a href="#">Division</a>
                    	<div class="megamenu megamenu-quarter-width">
                            <div class="megamenu-row">
                                    <div class="col12">
                                        <ul class="list-unstyled">
                                            <li><a href="#">Demo Link</a></li>
                                            <li><a href="#">Demo Link Two</a></li>
                                            
                                            <li><a href="#">Demo Link Three</a></li>
                                            <li><a href="#">Demo Link Four</a></li>
                                            
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                    </li>
                      <li><a href="#">Schemes</a></li>
                      <li><a href="#">Guidelines</a></li>
                      <li><a href="#">Forms</a></li>
                      <li><a href="#">Statistics</a></li>
                      <li><a href="#">Acts & Rules</a></li>
                      <li><a href="#">Trade</a></li>
                      <li><a href="#">RTI</a></li>
                      <li><a href="#">RFD</a></li>
                       
                      
				</ul>
			</div>
   </div>        
</section>



<!--/.nav-wrapper-->

<section class="wrapper banner-wrapper">
    <div id="flexSlider" class="flexslider">
        <ul class="slides">
        	<li> <img src="/assets/templates/1/theme/images/banner/banner1.jpg"> </li>
			<li> <img src="/assets/templates/1/theme/images/banner/banner2.jpg"> </li>
            <li> <img src="/assets/templates/1/theme/images/banner/banner1.jpg"> </li>
			<li> <img src="/assets/templates/1/theme/images/banner/banner2.jpg"> </li>
           
        </ul>
    </div>
</section>
<div class="wrapper" id="skipCont"></div><!--/#skipCont-->
<section id="fontSize" class="wrapper body-wrapper ">
<div class="bg-wrapper top-bg-wrapper">
<div class="container">
	<!--<div class="about-dep-container">
    	<h2>About the Department</h2>
    	<p>The Department of Animal Husbandry and Dairying (AH&D) - now renamed as Department of Animal Husbandry Dairying & Fisheries (DADF) is one of the Departments in the Ministry of Agriculture and came into existence w.e.f. 1st February, 1991, by converting two divisions of the Department of Agriculture and Cooperation namely Animal Husbandry and Dairy Development into a separate Department. </p>
        <a href="#" class="readmore">Read More</a>
    </div>-->

  <div class="box-container">
  	<div class="minister-container-right">
    	<div class="minister-box clearfix">
                	<div class="minister-image"><img src="/assets/templates/1/theme/images/minister-img-1.jpg" alt=""></div>
                    
                    <div class="min-info">
                    	<h4>Hon’ble MoS</h4>
                        <h5>Dr. Sanjeev Kumar Balyan</h5>
                        <a href="#" title="Visit Page">Visit Page</a>
                    </div>
                </div>
   		  <div class="ebook-container clearfix">
           	<div class="content">e-Book of <span>Ministry</span>
            <a href="#" class="download"><i class="fa fa-file-pdf-o"></i> Download</a>
            </div>
            <img src="/assets/templates/1/theme/images/e-book.png"> 
            </div>
            <div class="clear"></div>
    </div>
  
  	<div class="division-container-left">
    	<h2>Division</h2>
        <ul>
            <li class="nlm"><a href="#">National Livestock Mission</a></li>
            <li class="cdd"><a href="#">Cattle and Dairy Development</a></li>
            <li class="fis"><a href="#">Fisheries</a></li>
            <li class="inc"><a href="#">International Cooperation</a></li>
            <li class="cst"><a href="#">Cash Section</a></li>
            <li class="adi"><a href="#">Admin I</a></li>
            <li class="lsh"><a href="#">Livestock Health</a></li>
            <li class="more"><a href="#">View All <i class="fa fa-angle-double-right"></i></a></li>
        </ul>
    </div>
    <div class="box-container-left">
    	<div class="whatsnew">
    	<h2>What's New</h2>
        <ul>
        <li><a href="#"> Improvement of maintenance of Files and quality of drafts in Admn.I section </a></li>
        <li><a href="#"> Performa for submission of tender for printing of annual report</a></li>
        <li><a href="#"> Quotations for printing of annual report</a></li>
        <li><a href="#"> Recruitment Of  One Post of Quarantine Officer in Pay Band -3 in the Animal Quarantine &amp; Certification Services, Chennai Under DAHD</a></li>
        <li><a href="#"> Govt. of India Resolution on Public Interest Disclosures &amp; Protection of Informer</a></li>
        <li><a href="#"> Recruitment to the three posts of skipper (Gereral central service Gr. 'A' Gazetted, Non-Ministerial) Central Institute of Fisheries Nautical &amp; Engineering Training, Cochin</a></li>
        </ul>
        <a href="#" class="btn-view">View All  <i class="fa fa-angle-double-right"></i></a>
    	<div class="clear"></div>
        </div>
        <div class="quick-links">
        	<ul>
            <li class="tranders"><a href="#"><span></span> Tranders</a></li>
            <li class="intradadf"><a href="#"><span></span> Intradadf</a></li>
            <li class="recurement"><a href="#"><span></span> Recuritment</a></li>
            <li class="forms"><a href="#"><span></span> Forms</a></li>
            </ul>
        </div>
    </div>
    <div class="clear"></div>
  </div>  
    
</div>
</div>



</section><!--/.body-wrapper-->

<!--/.banner-wrapper-->
<section class="wrapper banner-wrapper home-btm-slider">
<div class="photogallery-container">
    <div class="container">
       <div class="gallery-area clearfix">
       <div class="gallery-heading">
       		<h3>Photo Gallery</h3>
            <a class="bttn-more bttn-view" href="#"><span>View All</span></a>
            </div>
            <div class="gallery-holder">
            <div id="galleryCarousel" class="flexslider">
                <ul class="slides">
                    <li data-thumb="/assets/templates/1/theme/images/crousal/1.jpg"><img src="/assets/templates/1/theme/images/crousal/1.jpg" />
                    	<div class="flex-caption">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</div>
                    </li>
                    <li data-thumb="/assets/templates/1/theme/images/crousal/2.jpg"><img src="/assets/templates/1/theme/images/crousal/2.jpg" />
                    
                    	<div class="flex-caption">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, w</div>
                    
                    </li>
                    <li data-thumb="/assets/templates/1/theme/images/crousal/3.jpg"><img src="/assets/templates/1/theme/images/crousal/3.jpg" />
                    
                    	<div class="flex-caption">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, w</div>
                    
                    </li>	
         
                </ul>
            </div>
           </div> 
       </div>
       
       <div class="releted-photo">
       	<div class="reletedphoto-container">
        	<h3>Related Photos</h3>
            <ul>
            	<li><a href="#">Photo of TCD meeting -2015 held at bengaluru on 4-5th June, 2015</a></li>
                <li><a href="#">kashi Vasanth nagpur Part-I</a></li>
                <li><a href="#">kashi Vasanth nagpur Part-II</a></li>
                <li><a href="#">kashi Vasanth nagpur </a></li>
                <li><a href="#">RSFPD Jammu </a></li>
                <li><a href="#">RSFPD Hisar </a></li>
            </ul>
            <a href="#" class="btn-view">View All  <i class="fa fa-angle-double-right"></i></a>
        </div>
        
       </div>
       <div class="clear"></div>
       </div>
       
    </div>
</section><!--/.banner-wrapper-->

<div class="container">
  <div class="white-container clearfix">
  	<div class="imp-link">
    	<h3>Related Links</h3>
        <div class="implink-content with-icon">
        	<ul>
            	<li class="agri"><a href="#"><span></span> Dept. of Agriculture</a></li>
                <li class="farmar"><a href="#"><span></span> Farmer’s Portal</a></li>
                <li class="dare"><a href="#"><span></span> DARE</a></li>
                
            </ul>
        </div>
        <div class="implink-content with-icon">
        	<ul>
            	<li class="cpgram"><a href="#"><span></span> CPGRAM</a></li>
                <li class="pg"><a href="#"><span></span> Public Grievances</a></li>
                <li class="rupee"><a href="#"><span></span> Invest India</a></li>
            </ul>
        </div>
        
        <div class="implink-content implink-content-last">
        	<ul>
            	<li><a href="#">Bay of Bengal Large Marine Ecosytem Project India</a></li>
                <li><a href="#">Indian Ocean Tunna Commission for Asia and the Pacific</a></li>
                <li><a href="#">Animal Production and Health Commission for Asia and the Pacific</a></li>
            </ul>
            
            <a href="#" class="btn-view">View All  <i class="fa fa-angle-double-right"></i></a>
        </div>
        
        <div class="clear"></div>
    </div>
    <div class="visitor">
    	<h3>Feedback</h3>
    	
        <ul>
        	<li><a href="#">Expert Committee Report -Deep Sea Fishing</a></li>
            <li><a href="#">Send Feedback on:- feedback-dahd@nic.in</a></li>
            <li><a href="#">Draft Marine Fishries (Regulation &amp; Management) Bill</a></li>
        </ul>
    
    
    
   </div>
    <div class="clear"></div>
  </div>  
    
    
</div>

<section class="wrapper carousel-wrapper">
	<div class="container carousel-container">
    	<div id="flexCarousel" class="flexslider carousel">
          <ul class="slides">
           <li><a target="_blank" href="http://ncf.nic.in/" title="NATIONAL CULTURE FUND, External Link that opens in a new window"><img src="/assets/templates/1/theme/images/national-culture.png" alt=""></a></li>
            <li><a target="_blank" href="http://india.gov.in/" title="National Portal of India, External Link that opens in a new window"><img src="/assets/templates/1/theme/images/india-gov.png" alt=""></a></li>
            <li><a target="_blank" href="https://data.gov.in/" title="Data portal, External Link that opens in a new window" ><img src="/assets/templates/1/theme/images/data-gov.png" alt=""></a></li>
            <li><a target="_blank" href="http://www.makeinindia.com/" title="Make In India, External Link that opens in a new window">
            <img src="/assets/templates/1/theme/images/makeinindia.png" alt=""></a></li>
            <li><a target="_blank" href="http://www.incredibleindia.org/en/" title="Incredible India, External Link that opens in a new window">
            <img src="/assets/templates/1/theme/images/incredible-india.png" alt=""></a></li>
            <li><a target="_blank" href="https://mygov.in/" title="MyGov, External Link that opens in a new window"><img src="/assets/templates/1/theme/images/mygov.png" alt=""></a></li>
            
             <li><a target="_blank" href="https://pmnrf.gov.in/" title="Prime Minister's National Relief Fund, External Link that opens in a new window"><img src="/assets/templates/1/theme/images/pmnrf.png" alt=""></a></li>
            
          </ul>  
    </div>
    </div>
</section><!--/.carousel-wrapper-->


<footer class="wrapper footer-wrapper">
	<div class="footer-top-wrapper">
    	<div id="footer-menu" class="container footer-top-container editable" widget-title="test widget" widget-id="3">
        	<ul>
            	<li><a href="#">Website Policies</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Help</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Feedback</a></li>
                <li><a href="#">Visitor&acute;s Summary</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom-wrapper">
    	<div class="container footer-bottom-container">
        	<div class="footer-content clearfix">
           
        <div class="copyright-content">
            	Website Content Managed by Department of Animal Husbandry Dairying & Fisheries, MoA, GoI
            <span>Designed, Developed and Hosted by  <a target="_blank" title="NIC, External Link that opens in a new window" href="http://www.nic.in/">National Informatics Centre</a> ( NIC )</span>
            
            
            </div>
            
             <div class="logo-cmf">
            	<a target="_blank" href="#"><img alt="" src="/assets/templates/1/assets/images/cmf-logo.png"></a>
            </div>
                </div>
        </div>
    </div>
</footer><!--/.footer-wrapper-->


<!-- From Here Modal Get start -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
          <form enctype="multipart/form-data" id="widgetForm">
          

        </form>
      </div>
      <div class="modal-footer">
      <div class="alert alert-success" style="display: none;">
            <strong>Success!</strong> This alert box could indicate a successful or positive action.
      </div>
      <div class="modal-error" >
        <strong>Danger!</strong> This alert box indicates a dangerous or potentially negative action.
     </div>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" id="" class="btn btn-primary save-content">Save Content</button>
      </div>
    </div>
  </div>
</div>
<!-- From Here Modal Get end -->
</body>
</html>
