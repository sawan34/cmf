<script type="text/javascript" src="/assets/widget/js/wd_title-to-save.js"></script>
<script type="text/javascript" src="/assets/widget/js/initiative.js"></script>
<script type="text/javascript" src="/assets/widget/js/headerimage.js"></script>
<script type="text/javascript" src="/assets/widget/js/wd_menu-builder.js"></script>

<!-- Custom styles for this template -->
<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/edit.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap-switch.css">
<script type="text/javascript" src="/assets/js/bootstrap-switch.js"></script>


<script type="text/javascript">
    
    $("[name='my-checkbox']").bootstrapSwitch();
</script>
<style type="text/css">
    .head-panel{
       margin-bottom:0px !important;
    }
    .heading-panel{
       // color: #FFF;
       // background-color: #111010 !important;
       // border-color: #111010;
    }
    .options input{
    margin:0;padding:0;
    -webkit-appearance:none;
       -moz-appearance:none;
            appearance:none;
}
</style>
<script>
$(document).ready(function(){
    $("[name='my-checkbox']").bootstrapSwitch();
    $('input[name="my-checkbox"]').on('switchChange.bootstrapSwitch', function(event, state) {
     if(!state){
        $( ".editable" ).each(function( index ) {
          //console.log( index + ": " + $( this ).text() );
          var t = $(this);
          var widgetAreaId =  t.attr('id');
          var title = t.attr('widget-title');
          var widgetId = t.attr('widget-id');
          var editSpan = '<span class="'+widgetAreaId+ ' edit-ele" >Edit</span>';
          t.addClass("edit-on");
          t.append(editSpan);

        });
     }else{
        $( ".editable" ).each(function( index ) {
         // console.log( index + ": " + $( this ).text() );
          $(this).removeClass("edit-on");
          $(this ).find('span.edit-ele').remove();
        });
     }
});
});
</script>
