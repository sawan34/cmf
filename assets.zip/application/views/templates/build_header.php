<!-- Custom styles for this template -->

<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/edit.css" rel="stylesheet">
<script type="text/javascript" src="/assets/templates/1/assets/js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="http://www.bootstrap-switch.org/dist/js/bootstrap-switch.js"></script>

<style type="text/css">
    .head-panel{
       margin-bottom:0px !important;
    }
    .heading-panel{
       // color: #FFF;
       // background-color: #111010 !important;
       // border-color: #111010;
    }
</style>
<header>
    <div class="panel panel-default head-panel ">
        <div class="panel-heading heading-panel">

            <input type="checkbox" name="my-checkbox" checked data-on-text="Edit Mode" data-off-text="Preview Mode"  data-handle-width ="200"  >
            <button class="btn btn-default pull-right">Sign Out</button>

        </div>

    </div>
</header>