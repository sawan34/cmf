<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Codeigniter Multilevel Menu - Example Index</title>
</head>
<body>
	<ul>
		<li><a href="<?php echo site_url("test/basic") ?>">Basic Example</a></li>
		<li><a href="<?php echo site_url("test/inject") ?>">Basic Example With inject men item</a></li>
		<li><a href="<?php echo site_url("test/bootstrap1") ?>">Twitter Bootstrap Example 1</a></li>
		<li><a href="<?php echo site_url("test/bootstrap2") ?>">Twitter Bootstrap Example 2</a></li>
	</ul>
</body>
</html>