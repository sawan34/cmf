<!-- Content Section Starts -->
<div class="content-section">  
    <div class="container">
        <h2 class="heading1 borderd-bottom">Create Website</h2>
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-7 col-xs-12 image-subscribe">

                <?php echo form_open('', array('class' => 'login-form subscribe')) ?>                                
                <div class="form-group clearfix">
                    <label for="site_url" class="col-sm-4 control-label">Enter URL of website</label>
                    <div class="col-sm-8">
                        <input type="url" class="form-control" id="site_url" autocomplete="off" name="site_url" placeholder="url (eg: http://abc.gov.in)" value="<?php echo set_value('linked-url'); ?>" required>
                        <span class="help-block">Type your page's url (eg: http://abc.gov.in)</span>
                        <span class="text-warning"><?php echo form_error('site_url'); ?></span>
                    </div>
                </div>
                <div class="form-group clearfix">
                    <label for="inputEmail3" class="col-sm-4 control-label"></label>
                    <div class="col-sm-8">
                        <button type="submit" class="btn btn-block btn-subscribe">Create</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>

