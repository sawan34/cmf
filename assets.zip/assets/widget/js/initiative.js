/*
 * parameter to be passes
 * 1.widgetAreaId  :- This is html id which is used to identify the area 
 *                    of widget and it is mapped to the widget id .But 
 *                    this id is added as class in edit button .
 * 2.widget_id     :- This is the unique id defined to the every
 *                    widget . This id is fetched when page get load 
 *                    from the data container tag of html "widget-id"
 *                    is mapped to the it.
 * 3.modalId       :- This is main modal id which load every time
 * 4.siteId        :- It contain site id.
 * 5.paths         :- It is object which contain the paths of diffrent ajax call for 
 *                    update,create etc.
 * 6.site_widget_id :- This contain database id of the table "site_widgets"                    
 * 
 */

(function(widgetAreaId, modalId, siteId) {
    var formData = '<div class="form-group"><label class="control-label">Government of India Initiative</label></div>';
    var formContent;
    var site_widget_id = 0;
    var initiative_id = 0,
            widget_id = 0,
            saveButtonId = 'button',
            paths = {listingPath: "/widgets/initiatives/", getPath: "/widgets/initiatives/widget_details/", updatePath: "/widgets/initiatives/update/", createPath: "/widgets/initiatives/create"};
    $(function() {
        var siteData = get(function(data) {
            widgetData = $.parseJSON(data);
            if (widgetData.hasOwnProperty('site_widget_id')) {
                site_widget_id = widgetData.site_widget_id;
            }
            t = $("#" + widgetAreaId);
            if (widgetData !== "")
            {
                console.log(widgetData);
                initiative_id = widgetData.initiative_id;
                t.find('a').attr('href', widgetData.initiative_link);
                t.find('a').attr('title', widgetData.initiative_name);
                t.find('img').attr('src', '/assets/images/' + widgetData.initiative_image_url);
            }
        }
        , function(data) {
            console.log(data);
        }
        );

        $('#' + widgetAreaId).on("click", 'span.' + widgetAreaId, function(event) {
            var initiativeData = getListing(function(data) {
                var listingData = data;
                if (listingData.length > 0)
                {
                    for (i = 0; i < listingData.length; i++)
                    {
                        console.log(initiative_id);
                        if (initiative_id === listingData[i].id)
                        {
                            formData += '<div class="radio"><input type = "radio" name = "initiative_id" value ="' + listingData[i].id + '"  data-title="' + listingData[i].name + '" data-link="' + listingData[i].link + '" data-image="' + listingData[i].image_url + '" checked />';
                        }
                        else
                        {
                            formData += '<div class="radio"><input type = "radio" name = "initiative_id" value ="' + listingData[i].id + '"  data-title="' + listingData[i].name + '" data-link="' + listingData[i].link + '" data-image="' + listingData[i].image_url + '"/ >';
                        }
                        formData += '<img src = "/assets/images/' + listingData[i].image_url + '" /></div>';
                    }
                }
                openModel(formData);

            }
            , function(data) {
                console.log("Error");
            }
            );
            return false;
        });
        // !!!!!! fix it
        // 
        $('#' + modalId).on("click", '.save-content', function(event) {
            if (event.currentTarget.id != saveButtonId)
             {
             $("#" + modalId + " .alert-danger").show();
             return false;
             }
            console.log(saveButtonId);
            var radioButton = $('.modal-body input[name=initiative_id]:checked');
            initiative_id = $(radioButton).val();
            var widgetId = widget_id;
            if (site_widget_id !== 0)
            {
                //update(site_widget_id);
                update(site_widget_id, widgetId, initiative_id, function(initiative_id) {
                    t = $("#" + widgetAreaId);
                    $('#' + modalId).modal('hide');
                    $('#' + modalId).find("form").empty();
                    d = new Date();
                    t.find('a').attr('href', $(radioButton).attr('data-link'));
                    t.find('a').attr('title', $(radioButton).attr('data-title'));
                    t.find('img').attr('src', '/assets/images/' + $(radioButton).attr('data-image') + '?' + d.getTime());
                });
            }
            else {
                create(widgetId, initiative_id, function(data) {
                    t = $("#" + widgetAreaId);
                    $('#' + modalId).modal('hide');
                    $('#' + modalId).find("form").empty();
                    d = new Date();
                    t.find('a').attr('href', $(radioButton).attr('data-link'));
                    t.find('a').attr('title', $(radioButton).attr('data-title'));
                    t.find('img').attr('src', '/assets/images/' + $(radioButton).attr('data-image') + '?' + d.getTime());
                });
            }
        });
    });

    /*
     * Below is the modal operation 
     * showModel() - is for the opening of model
     * closeModel() - is for the closing of the model
     */
    function openModel() {
        modelDom = $('#' + modalId);
        modelDom.on('shown.bs.modal', function() {
            $("#" + modalId + " .alert-success").hide();
            $("#" + modalId + " .modal-error").hide();
            t = $("#" + widgetAreaId);            
            saveButtonId = widgetAreaId + '-' + widget_id;
            $('#' + modalId + ' .save-content').attr('id', saveButtonId);
        });
        modelDom.on('hidden.bs.modal', function() {
            formData = '';
            $(modelDom).find("form").empty();
            $(modelDom).find(".save-content").attr('id', '');
        });
        modelDom.modal('show');
        modelDom.find('.modal-body form').append(formData);
    }
    /*
     * Below are the ajax CRUD implementation
     * get()    - get data
     * update() - update data 
     * delete() - delete data
     * create() - create data
     *
     */
    function get(success_cb, error_cb) {
        widget_id = $("#" + widgetAreaId).attr("widget-id");
        $.ajax({
            url: paths.getPath + widget_id + "/" + siteId + "",
            dataType: "text",
            success: function(data) {
                success_cb(data);
            },
            error: function(data) {
                error_cb(data);
            }
        });
    }

    function getListing(success_cb, error_cb) {
        $.ajax({
            url: paths.listingPath,
            dataType: "json",
            success: function(data) {
                success_cb(data);
            },
            error: function(data) {
                error_cb(data);
            }
        });
    }

    function update(site_widget_id, widgetId, initiative_id, callBackSuccess) {
        $.ajax({
            type: "POST",
            url: paths.updatePath + site_widget_id,
            data: "widget_id=" + widgetId + "&widget_area_id=1&initiative_id=" + initiative_id,
            success: function(data) {
                callBackSuccess(initiative_id);
            },
            error: function() {
                $("#" + modalId + " .alert-danger").show();
                return false;
            }
        });
    }
    function create(widgetId, initiative_id, callBackSuccess) {
        $.ajax({
            type: "POST",
            url: paths.createPath,
            data: "widget_id=" + widgetId + "&widget_area_id=" + widgetAreaId + "&initiative_id=" + initiative_id,
            success: function(data) {
                callBackSuccess(initiative_id);
            },
            error: function() {
                $("#" + modalId + " .alert-danger").show();
                return false;
            }
        });
    }
    function deletedata() {
    }

})('goii', 'editModal', 1);