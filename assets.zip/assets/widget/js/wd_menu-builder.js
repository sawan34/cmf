/*
	*This is the widget for the menu
	*/
  (function(modalId,siteId){
    menuFunction('header-menu',modalId,siteId);
    menuFunction('footer-menu',modalId,siteId);
    function menuFunction( widgetAreaId,modalId,siteId){ 
      var formData ='',
      site_widget_id=0,
      widget_id='',
      hiContainer="strong",
      userMenuRawJson = '',
      engContainer="span#site-eng",
      saveButtonId='button_'+widgetAreaId,
      paths={menuListingPath:"/widgets/menubuilder/get_all_menu/",updatePath:"/widgets/menubuilder/updateUserMenuItems/",createPath:"/widgets/menubuilder/insertUserMenuItems/",frontMenuPath:"/widgets/menubuilder/getUserMenuItems/"
    };  
    $(function(){ 
      widget_id = $("#"+widgetAreaId).attr('widget-id');
      onLoadUserMenu(function (data) 
      {
        var d = $.parseJSON(data);
        if(data !==''){ 
         site_widget_id = d.site_widget_id; 
         userMenuRawJson = d.menuRawJson;
         $("#"+widgetAreaId).html(d.menu);
         $('#loadedMenu').removeClass('loadedMenu');
         $('#loadedMenu').addClass('menuzord-menu');
       }
     });
      $('#'+widgetAreaId).on("click", 'span.'+widgetAreaId, function(event) {
        var menuItems = getAllMenus(function(data){
         formData = data;
       }
       ,function(error){
        showError(error);
      });  
        openModel(); 
        return false;
      }); //click function ends
      $('#'+widgetAreaId).on("click", 'span.'+widgetAreaId, function(event) {
        var menuItems = getAllMenus(function(data){
          formData = data;
        }
        ,function(error){
          showError(error);
        });  
        openModel(); 
        return false;
      }); //click function ends 
      $('#'+modalId).on("click", '#'+saveButtonId, function(event) {
        var t = $('#'+modalId),selectedData={},id,slug,parent,name,number,c=0;
        t.find('input:checkbox').each(function() 
        {    
          if($(this).is(':checked'))
          {
            slug = $(this).attr('name');
            if($(this).attr('data-parent-id')==='' || $(this).attr('data-parent-id')=='undefined' ||$(this).attr('data-parent-id').length===0){
             parent = "";
           }else{
            parent = $(this).attr('data-parent-id');
          }
          selectedData[c] = {
            'slug':slug,
            'parent':parent,
            'id':$(this).attr('data-menu-id'),
            'number':$(this).attr('data-menu-order'),
            'name':$(this).val()
          };
            //[$(this).attr('data-parent-id')];
            c++;
          } 
        });
        if(site_widget_id >0){
          update(site_widget_id,selectedData);
        }else{
          create(3,widgetAreaId,selectedData);
        }  
      });     

    });
		/*
  * Below is the modal operation 
  * showModel() - is for the opening of model
  * closeModel() - is for the closing of the model
  */
  function openModel() {
   var modelDom = $('#' + modalId);
   modelDom.on('shown.bs.modal', function () {
    console.log('modal On');
    if(formData !==''){
      $("#"+modalId).find("form").html(formData);
      $("#"+modalId).find("form").html(formData);
      $('#'+modalId+' .save-content').attr('id',saveButtonId);
      modelDom.find('input').change(function() {
        if ($(this).is(':checked')) {
          var parentId= $(this).attr('data-parent-id');
          if(parentId!==''){
            modelDom.find('#menu_'+parentId).attr("checked","checked");
          }
        } else {
          console.log('Unchecked');
        }
      });
    }
    if(site_widget_id > 0){
      console.log("New India");
      var menuParse = $.parseJSON(userMenuRawJson);
      $.each(menuParse, function(idx, obj) {
        $("#"+modalId).find("form #menu_"+obj.id).attr('checked','checked');
      });
    }
  });
   modelDom.on('hidden.bs.modal', function () {
    formData ='';
  });
   modelDom.modal('show');
 }
  /*
   * Below are the ajax CRUD implementation
   * get()    - get data
   * update() - update data 
   * delete() - delete data
   * create() - create data
   *
   */
   function onLoadUserMenu(success_cb, error_cb) {
    widget_id = widget_id;
    console.log(widgetAreaId);
    $.ajax({
      url: paths.frontMenuPath +widget_id+"/"+ siteId +"/"+widgetAreaId+"/",
      dataType: "text",
      success: function(data) {
        success_cb(data);
      },
      error: function(data){
        console.log('no data');
        error_cb(data);
      }
    });
  }


  function getAllMenus(success_cb,error_cb) {
    $.ajax({
      url: paths.menuListingPath+widgetAreaId+"/",
      dataType: "text",
      success: function(data) {
        success_cb(data);
      },
      error: function(data){
        error_cb(data);
      }
    });
   }//end of get function

   function create(widget_id,widgetAreaId,menuData){
    var data ={
      "widget_id":widget_id,
      "siteID":siteId,
      "widget_area_id":widgetAreaId,
      "menuData":menuData
    };
    $.ajax({
      type: "POST",
      url: paths.createPath,
      //dataType: 'json',
      data: data,
      success: function(data) {
       //callBackSuccess(titleHindi,titleEnglish);
       showSuccess("Menu Created");
       location.reload(); 
     },
     error: function(error) {
      console.error();
      showError(error);
      return false;
    }
  });
  }

  function update(site_widget_id,menuData){
   var data ={
    "site_widget_id":site_widget_id,
    "menuData":menuData
  };
  $.ajax({
    type: "POST",
    url: paths.updatePath,
      //dataType: 'json',
      data: data,
      success: function(data) {
       //callBackSuccess(titleHindi,titleEnglish);
       showSuccess("Menu Updated");
       location.reload(); 
     },
     error: function(error) {
      showError(error);
      return false;
    }
  });
}

   //start of messages funcitons
   function showError(msg){
     var errorSelector = $("#"+modalId + " .modal-error");
     errorSelector.empty();
     errorSelector.empty();
     errorSelector.text('Error! '+msg);
     errorSelector.show();
   }

   function showSuccess(msg){
    var errorSelector = $("#"+modalId + " .alert-success");
    errorSelector.empty();
    errorSelector.empty();
    errorSelector.text('Success! '+msg);
    errorSelector.show();
  }

}
})('editModal',1);