/*
 * parameter to be passes
 * 1.widgetAreaId  :- This is html id which is used to identify the area 
 *                    of widget and it is mapped to the widget id .But 
 *                    this id is added as class in edit button .
 * 2.widget_id     :- This is the unique id defined to the every
 *                    widget . This id is fetched when page get load 
 *                    from the data container tag of html "widget-id"
 *                    is mapped to the it.
 * 3.modalId       :- This is main modal id which load every time
 * 4.siteId        :- It contain site id.
 * 5.paths         :- It is object which contain the paths of diffrent ajax call for 
 *                    update,create etc.
 * 6.site_widget_id :- This contain database id of the table "site_widgets"                    
 * 
 */

 (function(widgetAreaId,modalId,siteId) {
  var formData = '<div class="form-group"><label for="message-text" class="control-label">Hindi Title:</label><input type="text" name="site_title_hi" id="site_title_hi" class="form-control" value="" required="required" pattern="" title=""></div><div class="form-group"><label for="message-text" class="control-label">English Title:</label><input type="text" name="site_title_en" id="site_title_en" class="form-control" value="" required="required" pattern="" title=""></div>';
  var site_widget_id=0,
      widget_id=0,
      hiContainer="strong",
      engContainer="span#site-eng",
      saveButtonId='button',
      paths={getPath:"/widget/widget_details/",updatePath:"/widget/update/",createPath:"/widget/siteinfo"}; 
  $(function() {
    var siteData = get(function(data){
        parseData =  $.parseJSON(data);         
        widgetData = parseData.widget_data;
        console.log(parseData);
        if(parseData.hasOwnProperty('site_widget_id')){
          site_widget_id=parseData.site_widget_id;
        }
        console.log(site_widget_id);   
        t=$("#"+widgetAreaId);
        if(widgetData.site_title_hi !=''){
          t.find(hiContainer).text(widgetData.site_title_hi);  
        }
        if(widgetData.site_title_en !=''){   
          t.find(engContainer).text(widgetData.site_title_en); 
        }    
      }
      ,function(data){
        console.log(data);
      }
      );

    $('#'+widgetAreaId).on("click", 'span.'+widgetAreaId, function(event) {
      openModel(formData);
      return false;
    });
    // !!!!!! fix it
    // 
    $('#'+modalId).on("click", '.save-content', function(event) {
      if(event.currentTarget.id!=saveButtonId)
       {
        $("#"+modalId + " .alert-danger").show();
       } 
      console.log(saveButtonId);
      var titleHindi = $('.modal-body #site_title_hi').val();
      var titleEnglish = $('.modal-body #site_title_en').val();
      var widgetId = widget_id;
      if(site_widget_id!=0)
      {
        //update(site_widget_id);
        update(site_widget_id,widgetId,titleHindi,titleEnglish,function(titleHindi,titleEnglish){
          t=$("#"+widgetAreaId);
          t.find(hiContainer).text(titleHindi);  
          t.find(engContainer).text(titleEnglish);
          $('#'+modalId).modal('hide');
        });
      }
      else{
        create(widgetId, titleHindi,titleEnglish,function(data){
          t=$("#"+widgetAreaId);
          t.find(hiContainer).text(titleHindi);  
          t.find(engContainer).text(titleEnglish);
          $('#'+modalId).modal('hide');
        });
      }
    });
  });

  /*
  * Below is the modal operation 
  * showModel() - is for the opening of model
  * closeModel() - is for the closing of the model
  */
  function openModel(formData) {
    modelDom = $('#' + modalId);
    modelDom.on('shown.bs.modal', function () {
      t=$("#"+widgetAreaId);
      hindiTitle = t.find(hiContainer).text();  
      englishTitle= t.find(engContainer).text();
      $('#'+modalId+' input#site_title_hi').val(hindiTitle);
      $('#'+modalId+' input#site_title_en').val(englishTitle);
      saveButtonId = widgetAreaId+'-'+widget_id;
      $('#'+modalId+' .save-content').attr('id',saveButtonId);
    });
    modelDom.on('hidden.bs.modal', function () {
      $(this).find("form").empty();
      $(this).find(".save-content").attr('id','');
    });
    modelDom.modal('show');
    modelDom.find('.modal-body form').append(formData);            
  }
  /*
   * Below are the ajax CRUD implementation
   * get()    - get data
   * update() - update data 
   * delete() - delete data
   * create() - create data
   *
   */
   function get(success_cb, error_cb) {
    widget_id = $("#"+widgetAreaId).attr("widget-id");
    $.ajax({
      url: paths.getPath + widget_id + "/" + siteId + "",
      dataType: "text",
      success: function(data) {
        success_cb(data);
      },
      error: function(data){
        error_cb(data);
      }
    });
  }

  function update(site_widget_id,widgetId,titleHindi,titleEnglish,callBackSuccess) {
    $.ajax({
      type: "POST",
      url: paths.updatePath+site_widget_id,
      data: "widget_id=" + widgetId + "&widget_area_id=1&site_title_hi=" + titleHindi + "&site_title_en=" + titleEnglish,
      success: function(data) {
        $(".alert-success").show();
        callBackSuccess(titleHindi,titleEnglish);
      },
      error: function() {
        $("#"+modalId + " .alert-danger").show();
      }
    });
  }
  function create(widgetId, titleHindi, titleEnglish,callBackSuccess) {
    $.ajax({
      type: "POST",
      url: paths.createPath,
      data: "widget_id=" + widgetId + "&widget_area_id=1&site_title_hi=" + titleHindi + "&site_title_en=" + titleEnglish,
      success: function(data) {
       callBackSuccess(titleHindi,titleEnglish);
       $(".alert-success").show();
      },
        error: function() {
        alert("failure");
      }
    });
  }
  function deletedata() {
  }

})('header-logo','editModal',1);