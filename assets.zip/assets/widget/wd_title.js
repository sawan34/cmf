(function(widgetId, containerId, url) {
    var formData = '<div class="form-group"><label for="message-text" class="control-label">Hindi Title:</label><input type="text" name="site_title_hi" id="site_title_hi" class="form-control" value="" required="required" pattern="" title=""></div><div class="form-group"><label for="message-text" class="control-label">English Title:</label><input type="text" name="site_title_en" id="site_title_en" class="form-control" value="" required="required" pattern="" title=""></div>';
        var site_widget_id=0;
    $(function() {
        var siteData = get(1, 1, function(data){
         parseData =  $.parseJSON(data);         
         widgetData = parseData.widget_data;
         console.log(parseData);
         if(parseData.hasOwnProperty('site_widget_id')){
            site_widget_id=parseData.site_widget_id;
            }
         console.log(site_widget_id);   
         t=$("a#"+containerId);
         if(widgetData.site_title_hi !=''){
         t.find("strong").text(widgetData.site_title_hi);  
            }
         if(widgetData.site_title_en !=''){   
         t.find("span").text(widgetData.site_title_en); 
         }    

        },function(data){console.log(data);});

        $(document).on("click", "#" + widgetId, function(event) {
            openModel('editModal', formData);
            t=$("a#"+containerId);
			hindiTitle = t.find("strong").text();  
            englishTitle= t.find("span#site-eng").text();
            $('#editModal input#site_title_hi').val(hindiTitle);
            $('#editModal input#site_title_en').val(englishTitle);       

            return false;
        });
        $(document).on("click", ".modal .save-content", function(event) {
            var titleHindi = $('.modal-body #site_title_hi').val();
            var titleEnglish = $('.modal-body #site_title_en').val();
            var widgetId = 1;
            if(site_widget_id!=0)
            {
                //update(site_widget_id);
                update(site_widget_id,widgetId,titleHindi,titleEnglish,function(titleHindi,titleEnglish){
                    t=$("a#"+containerId);
                    t.find("strong").text(titleHindi);  
                    t.find("span#site-eng").text(titleEnglish);
                    $('#editModal').modal('hide');
                });
            }
            else
            {
             create(widgetId, titleHindi,titleEnglish,function(data){
            	t=$("a#"+containerId);
                t.find("strong").text(titleHindi);  
                t.find("span#site-eng").text(titleEnglish);
                $('#editModal').modal('hide');
            });
        }
        });
       /*
        * Bootstrap event on close of the modal
        * All forms to empty if closing the modal
        * 
        */
            $('#editModal').on('hidden.bs.modal', function () {
                $("#editModal").find("form").empty();
            });
    });
    /*
     * Below is the modal operation 
     * showModel() - is for the opening of model
     * closeModel() - is for the closing of the model
     */
    function openModel(modelId, formData) {
        modelDom = $('#' + modelId);
        modelDom.modal('show');
        modelDom.find('.modal-body form').append(formData);            
    }
    /*
     * Below are the ajax CRUD implementation
     * get()    - get data
     * update() - update data 
     * delete() - delete data
     * create() - create data
     */
    function get(widget_id, site_id, success_cb, error_cb) {
        var json = "";
        $.ajax({
            url: "http://saasconfig.gov.in/widget/widget_details/" + widget_id + "/" + site_id + "",
            dataType: "text",
            success: function(data) {
                success_cb(data);
            },
            error: function(data){
                error_cb(data);
            }
        });
    }
    function update(site_widget_id,widgetId,titleHindi,titleEnglish,callBackSuccess) {
          $.ajax({
            type: "POST",
            url: '/widget/update/'+site_widget_id,
            data: "widget_id=" + widgetId + "&widget_area_id=1&site_title_hi=" + titleHindi + "&site_title_en=" + titleEnglish,
            success: function(data) {
                $(".alert-success").show();
                callBackSuccess(titleHindi,titleEnglish);
            },
            error: function() {
                alert("no update done");
            }
        });
    }
    function create(widgetId, titleHindi, titleEnglish,callBackSuccess) {
        $.ajax({
            type: "POST",
            url: '/widget/siteinfo',
            data: "widget_id=" + widgetId + "&widget_area_id=1&site_title_hi=" + titleHindi + "&site_title_en=" + titleEnglish,
            success: function(data) {
            	callBackSuccess(titleHindi,titleEnglish);
                $(".alert-success").show();
            },
            error: function() {
                alert("failure");
            }
        });
    }
    function deletedata() {
    }

})('site-title', 'header-logo');


